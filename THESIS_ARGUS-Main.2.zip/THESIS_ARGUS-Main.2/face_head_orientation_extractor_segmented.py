from __future__ import annotations

import argparse
import importlib
import json
import logging
import os
import warnings
from pathlib import Path
from typing import Any, List, Optional, Sequence, Tuple

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
logging.getLogger("absl").setLevel(logging.ERROR)
warnings.filterwarnings("ignore", category=UserWarning, module="google.protobuf")

DEPENDENCY_ERROR = None
FACE_MESH_CLASS = None
FloatArray = Any
try:
    import cv2
    import numpy as np
    from numpy.typing import NDArray

    FloatArray = NDArray[np.float64]

    for module_name in (
        "mediapipe.python.solutions.face_mesh",
        "mediapipe.solutions.face_mesh",
    ):
        try:
            FACE_MESH_CLASS = importlib.import_module(module_name).FaceMesh
            break
        except (AttributeError, ImportError, ModuleNotFoundError):
            continue
except ModuleNotFoundError as exc:
    cv2 = None
    np = None
    FACE_MESH_CLASS = None
    DEPENDENCY_ERROR = exc


DEFAULT_VIDEO_DIR = "DATA_COLLECTED_VIDEOS"
DEFAULT_SEGMENT_LENGTH_SEC = 60.0
DEFAULT_TARGET_FPS = 15.0
DEFAULT_MOUTH_OPEN_THRESH_NORM = 0.03
DEFAULT_OFFSCREEN_YAW_THRESH_DEG = 25.0
DEFAULT_SMOOTHING_ALPHA = 0.4

OUTPUT_PATTERN = "face_head_orientation_segment_*.json"

LANDMARK_IDX = {
    "nose_tip": 1,
    "chin": 199,
    "left_eye_outer": 33,
    "right_eye_outer": 263,
    "mouth_left": 61,
    "mouth_right": 291,
    "upper_lip": 13,
    "lower_lip": 14,
}

# Generic 3D face model points for solvePnP. The exact real-world scale is not
# used; the relative point layout is enough for yaw/pitch/roll estimation.
MODEL_POINTS_3D_VALUES = [
    (0.0, 0.0, 0.0),
    (0.0, -6.0, -2.0),
    (-4.5, 2.5, -2.5),
    (4.5, 2.5, -2.5),
    (-3.0, -2.0, -2.0),
    (3.0, -2.0, -2.0),
]


def ensure_dependencies() -> None:
    if DEPENDENCY_ERROR is None and FACE_MESH_CLASS is not None:
        return

    if DEPENDENCY_ERROR is not None:
        raise RuntimeError(
            "Missing video-processing dependency. Install requirements with: "
            'py -m pip install --upgrade opencv-python mediapipe numpy "protobuf<5"'
        ) from DEPENDENCY_ERROR

    raise RuntimeError(
        "MediaPipe is installed, but FaceMesh could not be found in this environment. "
        "Fix it with: py -m pip uninstall -y mediapipe && "
        'py -m pip install mediapipe==0.10.14 opencv-python numpy "protobuf<5"'
    )


def model_points_3d() -> FloatArray:
    return np.array(MODEL_POINTS_3D_VALUES, dtype=np.float64)


def rotation_vector_to_euler(rvec: FloatArray) -> Tuple[float, float, float]:
    rotation_matrix, _ = cv2.Rodrigues(rvec)
    sy = np.sqrt(rotation_matrix[0, 0] ** 2 + rotation_matrix[1, 0] ** 2)
    singular = sy < 1e-6

    if singular:
        pitch = np.arctan2(-rotation_matrix[1, 2], rotation_matrix[1, 1])
        yaw = np.arctan2(-rotation_matrix[2, 0], sy)
        roll = 0.0
    else:
        pitch = np.arctan2(rotation_matrix[2, 1], rotation_matrix[2, 2])
        yaw = np.arctan2(-rotation_matrix[2, 0], sy)
        roll = np.arctan2(rotation_matrix[1, 0], rotation_matrix[0, 0])

    return tuple(float(v) for v in np.degrees([yaw, pitch, roll]))


def smooth_pose(
    current_pose: Tuple[float, float, float],
    previous_pose: Optional[Tuple[float, float, float]],
    alpha: float,
) -> Tuple[float, float, float]:
    if previous_pose is None or alpha >= 1.0:
        return current_pose
    if alpha <= 0.0:
        return previous_pose

    return tuple(
        alpha * current_value + (1.0 - alpha) * previous_value
        for current_value, previous_value in zip(current_pose, previous_pose)
    )


def make_camera_matrix(width: int, height: int) -> FloatArray:
    focal_length = float(width)
    return np.array(
        [
            [focal_length, 0.0, width / 2.0],
            [0.0, focal_length, height / 2.0],
            [0.0, 0.0, 1.0],
        ],
        dtype=np.float64,
    )


def landmark_xy(landmarks: Sequence, index: int, width: int, height: int) -> FloatArray:
    point = landmarks[index]
    return np.array([point.x * width, point.y * height], dtype=np.float64)


def estimate_head_pose(
    landmarks: Sequence,
    width: int,
    height: int,
    camera_matrix: FloatArray,
    face_model_points: FloatArray,
) -> Optional[Tuple[float, float, float]]:
    image_points_2d = np.array(
        [
            landmark_xy(landmarks, LANDMARK_IDX["nose_tip"], width, height),
            landmark_xy(landmarks, LANDMARK_IDX["chin"], width, height),
            landmark_xy(landmarks, LANDMARK_IDX["left_eye_outer"], width, height),
            landmark_xy(landmarks, LANDMARK_IDX["right_eye_outer"], width, height),
            landmark_xy(landmarks, LANDMARK_IDX["mouth_left"], width, height),
            landmark_xy(landmarks, LANDMARK_IDX["mouth_right"], width, height),
        ],
        dtype=np.float64,
    )

    success, rvec, _ = cv2.solvePnP(
        face_model_points,
        image_points_2d,
        camera_matrix,
        np.zeros((4, 1), dtype=np.float64),
        flags=cv2.SOLVEPNP_ITERATIVE,
    )
    if not success:
        return None

    return rotation_vector_to_euler(rvec)


def compute_mouth_movement(
    landmarks: Sequence,
    width: int,
    height: int,
    mouth_open_thresh_norm: float,
) -> bool:
    upper_lip = landmark_xy(landmarks, LANDMARK_IDX["upper_lip"], width, height)
    lower_lip = landmark_xy(landmarks, LANDMARK_IDX["lower_lip"], width, height)

    lip_distance_px = float(np.linalg.norm(upper_lip - lower_lip))
    mouth_width_px = max(
        1.0,
        float(
            np.linalg.norm(
                landmark_xy(landmarks, LANDMARK_IDX["mouth_left"], width, height)
                - landmark_xy(landmarks, LANDMARK_IDX["mouth_right"], width, height)
            )
        ),
    )
    lip_distance_norm = lip_distance_px / mouth_width_px

    return lip_distance_norm > mouth_open_thresh_norm


def compute_face_frame_metrics(
    landmarks: Sequence,
    width: int,
    height: int,
) -> Tuple[float, float, float]:
    """Return normalized face position and size relative to the whole frame."""
    x_coords = [
        min(max(float(landmark.x) * width, 0.0), float(width))
        for landmark in landmarks
    ]
    y_coords = [
        min(max(float(landmark.y) * height, 0.0), float(height))
        for landmark in landmarks
    ]

    min_x, max_x = min(x_coords), max(x_coords)
    min_y, max_y = min(y_coords), max(y_coords)
    bbox_width = max(1.0, max_x - min_x)
    bbox_height = max(1.0, max_y - min_y)
    bbox_center_x = (min_x + max_x) / 2.0
    bbox_center_y = (min_y + max_y) / 2.0

    center_offset_x = (bbox_center_x - (width / 2.0)) / max(width / 2.0, 1.0)
    center_offset_y = (bbox_center_y - (height / 2.0)) / max(height / 2.0, 1.0)
    bbox_area_ratio = (bbox_width * bbox_height) / max(float(width * height), 1.0)

    return center_offset_x, center_offset_y, bbox_area_ratio


def segment_name(segment_index: int) -> str:
    return f"segment_{segment_index + 1:02d}"


def clean_previous_outputs(out_dir: Path) -> int:
    removed = 0
    for old_file in out_dir.glob(OUTPUT_PATTERN):
        old_file.unlink()
        removed += 1
    return removed


def write_segment(out_dir: Path, segment_index: int, records: List[dict]) -> Path:
    segment_id = segment_name(segment_index)
    out_path = out_dir / f"face_head_orientation_{segment_id}.json"
    out_path.write_text(json.dumps(records, indent=2), encoding="utf-8")
    print(f"[saved] {out_path} ({len(records)} records)")
    return out_path


def process_video(
    video_path: Path,
    out_dir: Path,
    *,
    segment_length_sec: float = DEFAULT_SEGMENT_LENGTH_SEC,
    target_fps: float = DEFAULT_TARGET_FPS,
    sample_every: Optional[int] = None,
    mouth_open_thresh_norm: float = DEFAULT_MOUTH_OPEN_THRESH_NORM,
    offscreen_yaw_thresh_deg: float = DEFAULT_OFFSCREEN_YAW_THRESH_DEG,
    smoothing_alpha: float = DEFAULT_SMOOTHING_ALPHA,
    min_detection_confidence: float = 0.5,
    min_tracking_confidence: float = 0.5,
    clean_output: bool = True,
) -> List[Path]:
    ensure_dependencies()

    video_path = Path(video_path)
    out_dir = Path(out_dir)

    if not video_path.exists():
        raise FileNotFoundError(f"Video not found: {video_path}")
    if segment_length_sec <= 0:
        raise ValueError("segment_length_sec must be greater than zero")
    if target_fps <= 0:
        raise ValueError("target_fps must be greater than zero")
    if sample_every is not None and sample_every < 1:
        raise ValueError("sample_every must be 1 or greater")
    if not 0.0 <= smoothing_alpha <= 1.0:
        raise ValueError("smoothing_alpha must be between 0 and 1")

    out_dir.mkdir(parents=True, exist_ok=True)
    if clean_output:
        removed = clean_previous_outputs(out_dir)
        if removed:
            print(f"[clean] Removed {removed} old face/head segment file(s) from {out_dir}")

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Could not open video: {video_path}")

    video_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frame_stride = sample_every or max(1, round(video_fps / target_fps))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    duration_sec = total_frames / video_fps if video_fps > 0 else 0.0

    print(f"[info] Video: {video_path}")
    print(f"[info] Output: {out_dir}")
    print(f"[info] Duration: {duration_sec / 60.0:.2f} min, FPS: {video_fps:.2f}")
    print(f"[info] Segment length: {segment_length_sec:.0f}s, frame stride: {frame_stride}")

    current_segment_index: Optional[int] = None
    current_samples: List[dict] = []
    written_files: List[Path] = []
    frame_idx = 0
    processed_frames = 0
    face_present_frames = 0
    camera_matrix: Optional[FloatArray] = None
    face_model_points = model_points_3d()
    previous_pose: Optional[Tuple[float, float, float]] = None

    try:
        with FACE_MESH_CLASS(
            static_image_mode=False,
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        ) as face_mesh:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                frame_idx += 1
                if frame_idx % frame_stride != 0:
                    continue

                processed_frames += 1
                height, width = frame.shape[:2]
                if camera_matrix is None:
                    camera_matrix = make_camera_matrix(width, height)

                timestamp_sec = (frame_idx - 1) / video_fps
                segment_index = int(timestamp_sec // segment_length_sec)
                segment_start_time = segment_index * segment_length_sec
                segment_time_sec = timestamp_sec - segment_start_time

                if current_segment_index is None:
                    current_segment_index = segment_index
                elif segment_index != current_segment_index:
                    written_files.append(write_segment(out_dir, current_segment_index, current_samples))
                    current_samples = []
                    current_segment_index = segment_index

                sample = {
                    "segment_id": segment_name(segment_index),
                    "timestamp_sec": round(timestamp_sec, 3),
                    "segment_time_sec": round(segment_time_sec, 3),
                    "face_present": False,
                    "pose_success": False,
                    "mouth_movement": False,
                    "face_center_offset_x": None,
                    "face_center_offset_y": None,
                    "face_bbox_area_ratio": None,
                    "head_pose_yaw_deg": None,
                    "head_pose_pitch_deg": None,
                    "head_pose_roll_deg": None,
                    "head_offscreen": False,
                }

                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = face_mesh.process(frame_rgb)

                if not results.multi_face_landmarks:
                    # Do not smooth a newly detected face against a stale pose
                    # from before a period where no face was visible.
                    previous_pose = None
                    current_samples.append(sample)
                    continue

                face_present_frames += 1
                face_landmarks = results.multi_face_landmarks[0].landmark
                mouth_open = compute_mouth_movement(
                    face_landmarks,
                    width,
                    height,
                    mouth_open_thresh_norm,
                )
                center_offset_x, center_offset_y, bbox_area_ratio = compute_face_frame_metrics(
                    face_landmarks,
                    width,
                    height,
                )
                raw_pose = estimate_head_pose(face_landmarks, width, height, camera_matrix, face_model_points)

                sample.update(
                    {
                        "face_present": True,
                        "mouth_movement": bool(mouth_open),
                        "face_center_offset_x": round(center_offset_x, 3),
                        "face_center_offset_y": round(center_offset_y, 3),
                        "face_bbox_area_ratio": round(bbox_area_ratio, 4),
                    }
                )

                if raw_pose is not None:
                    smoothed_pose = smooth_pose(raw_pose, previous_pose, smoothing_alpha)
                    yaw, pitch, roll = smoothed_pose
                    sample.update(
                        {
                            "pose_success": True,
                            "head_pose_yaw_deg": round(yaw, 2),
                            "head_pose_pitch_deg": round(pitch, 2),
                            "head_pose_roll_deg": round(roll, 2),
                            "head_offscreen": bool(abs(yaw) > offscreen_yaw_thresh_deg),
                        }
                    )
                    previous_pose = smoothed_pose

                current_samples.append(sample)
    finally:
        cap.release()

    if current_segment_index is not None and current_samples:
        written_files.append(write_segment(out_dir, current_segment_index, current_samples))

    face_rate = face_present_frames / processed_frames if processed_frames else 0.0
    print(
        f"[done] {video_path.name}: {len(written_files)} segment file(s), "
        f"{processed_frames} sampled frame(s), face present in {face_rate:.1%}"
    )
    return written_files


def find_video_files(video: Optional[str], video_dir: Optional[str], exam_id: Optional[str]) -> List[Path]:
    if video:
        return [Path(video)]

    search_dir = Path(video_dir or DEFAULT_VIDEO_DIR)
    if not search_dir.exists():
        raise FileNotFoundError(
            f"Video directory not found: {search_dir}. "
            "Pass --video or point --video-dir to your external DATA_COLLECTED_VIDEOS folder."
        )

    videos = sorted(search_dir.glob("*.mp4"))
    if exam_id:
        target_name = f"{exam_id}.mp4"
        videos = [path for path in videos if path.name.lower() == target_name.lower()]

    if not videos:
        label = f" matching {exam_id}" if exam_id else ""
        raise FileNotFoundError(f"No MP4 video files{label} found in {search_dir}")

    return videos


def default_output_dir(video_path: Path, output_root: Path) -> Path:
    video_stem = video_path.stem
    return output_root / video_stem / f"{video_stem}-FaceHeadOrientation_outputs"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Extract face/head orientation features into standalone segmented JSON artifacts. "
            "Default output is EXAM-PXX/EXAM-PXX-FaceHeadOrientation_outputs/."
        )
    )
    parser.add_argument("--video", help="Path to one MP4 file, e.g. DATA_COLLECTED_VIDEOS/EXAM-P01.mp4")
    parser.add_argument(
        "--video-dir",
        default=None,
        help=f"Folder containing MP4 files. Defaults to {DEFAULT_VIDEO_DIR} when --video is omitted.",
    )
    parser.add_argument("--exam-id", help="Optional exam ID filter, e.g. EXAM-P01")
    parser.add_argument(
        "--out",
        default=None,
        help="Output folder for single-video runs. For batch runs, use --output-root instead.",
    )
    parser.add_argument(
        "--output-root",
        nargs="?",
        const=".",
        default=".",
        help="Root folder for default per-exam outputs. If omitted after the flag, uses the current folder.",
    )
    parser.add_argument(
        "--segment-length-sec",
        type=float,
        default=DEFAULT_SEGMENT_LENGTH_SEC,
        help="Segment duration in seconds. Default: 60.",
    )
    parser.add_argument(
        "--target-fps",
        type=float,
        default=DEFAULT_TARGET_FPS,
        help="Maximum processing FPS when --sample-every is not set. Default: 15.",
    )
    parser.add_argument(
        "--sample-every",
        type=int,
        default=None,
        help="Use every Nth frame. Overrides --target-fps when provided.",
    )
    parser.add_argument(
        "--mouth-open-thresh-norm",
        type=float,
        default=DEFAULT_MOUTH_OPEN_THRESH_NORM,
        help="Mouth-open threshold as lip distance divided by face width. Default: 0.03.",
    )
    parser.add_argument(
        "--offscreen-yaw-thresh-deg",
        type=float,
        default=DEFAULT_OFFSCREEN_YAW_THRESH_DEG,
        help="Yaw threshold for head_offscreen. Default: 25 degrees.",
    )
    parser.add_argument(
        "--smoothing-alpha",
        type=float,
        default=DEFAULT_SMOOTHING_ALPHA,
        help="Pose smoothing alpha from 0 to 1. Higher means less smoothing. Default: 0.4.",
    )
    parser.add_argument("--min-detection-confidence", type=float, default=0.5)
    parser.add_argument("--min-tracking-confidence", type=float, default=0.5)
    parser.add_argument(
        "--no-clean",
        action="store_true",
        help="Keep old face_head_orientation_segment_*.json files in the output folder.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    videos = find_video_files(args.video, args.video_dir, args.exam_id)

    if args.out and len(videos) > 1:
        raise ValueError("--out can only be used when processing one video")

    output_root = Path(args.output_root)
    for video_path in videos:
        out_dir = Path(args.out) if args.out else default_output_dir(video_path, output_root)
        process_video(
            video_path,
            out_dir,
            segment_length_sec=args.segment_length_sec,
            target_fps=args.target_fps,
            sample_every=args.sample_every,
            mouth_open_thresh_norm=args.mouth_open_thresh_norm,
            offscreen_yaw_thresh_deg=args.offscreen_yaw_thresh_deg,
            smoothing_alpha=args.smoothing_alpha,
            min_detection_confidence=args.min_detection_confidence,
            min_tracking_confidence=args.min_tracking_confidence,
            clean_output=not args.no_clean,
        )


if __name__ == "__main__":
    main()
