from __future__ import annotations

import argparse
import json
import logging
import math
import os
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
logging.getLogger("absl").setLevel(logging.ERROR)
warnings.filterwarnings("ignore", category=UserWarning, module="google.protobuf")

DEFAULT_VIDEO_DIR = "DATA_COLLECTED_VIDEOS"
DEFAULT_SEGMENT_LENGTH_SEC = 60.0
DEFAULT_TARGET_FPS = 15.0

# Thresholds are conservative posture-feature flags, not cheating decisions.
# They are expressed in MediaPipe's normalized frame coordinates.
HAND_NEAR_MOUTH_DISTANCE_THRESH = 0.20
UPPER_TORSO_VISIBILITY_THRESH = 0.50
SHOULDER_TILT_THRESH = 0.18
UPPER_TORSO_CENTER_SHIFT_THRESH = 0.22
SHOULDER_WIDTH_NARROW_THRESH = 0.22
ELEVATED_HAND_MARGIN = 0.05
HIGH_MOVEMENT_THRESH = 0.06

OUTPUT_PATTERN = "posture_segment_*.json"

DEPENDENCY_ERROR = None
try:
    import cv2
    import mediapipe as mp
except ModuleNotFoundError as exc:
    cv2 = None
    mp = None
    DEPENDENCY_ERROR = exc


def ensure_dependencies() -> None:
    if DEPENDENCY_ERROR is None:
        return
    raise RuntimeError(
        "Missing posture-processing dependency. Install requirements with: "
        'py -m pip install mediapipe==0.10.14 opencv-python numpy "protobuf<5"'
    ) from DEPENDENCY_ERROR


def segment_name(segment_index: int) -> str:
    return f"segment_{segment_index + 1:02d}"


def landmark_xy(landmark: Any) -> Tuple[float, float]:
    return float(landmark.x), float(landmark.y)


def distance_xy(point1: Any, point2: Any) -> float:
    return math.hypot(float(point1.x - point2.x), float(point1.y - point2.y))


def midpoint(point1: Any, point2: Any) -> Dict[str, float]:
    return {
        "x": float((point1.x + point2.x) / 2.0),
        "y": float((point1.y + point2.y) / 2.0),
    }


def angle_deg(point1: Tuple[float, float], point2: Tuple[float, float]) -> float:
    return math.degrees(math.atan2(point2[1] - point1[1], point2[0] - point1[0]))


def landmark_visible(landmark: Any, threshold: float = UPPER_TORSO_VISIBILITY_THRESH) -> bool:
    visibility = getattr(landmark, "visibility", 1.0)
    return float(visibility) >= threshold


def clean_previous_outputs(out_dir: Path) -> int:
    removed = 0
    for old_file in out_dir.glob(OUTPUT_PATTERN):
        old_file.unlink()
        removed += 1
    return removed


def compute_posture_sample(
    pose_landmarks: Any,
    mp_pose: Any,
    *,
    previous_torso_center: Optional[Tuple[float, float]],
) -> Tuple[Dict[str, Any], Optional[Tuple[float, float]]]:
    base_sample: Dict[str, Any] = {
        "pose_detected": False,
        "upper_torso_visible": False,
        "hand_near_mouth": False,
        "upper_torso_posture_shift": False,
        "elevated_hands": False,
        "high_movement": False,
        "arm_asymmetry_deg": None,
        "shoulder_line_angle_deg": None,
        "shoulder_tilt": None,
        "upper_torso_center_offset_x": None,
        "upper_torso_center_offset_y": None,
        "upper_torso_center_shift": None,
        "shoulder_width_ratio": None,
        "torso_movement_delta": None,
    }

    if pose_landmarks is None:
        return base_sample, None

    try:
        landmarks = pose_landmarks.landmark
        left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER]
        right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER]
        left_wrist = landmarks[mp_pose.PoseLandmark.LEFT_WRIST]
        right_wrist = landmarks[mp_pose.PoseLandmark.RIGHT_WRIST]
        mouth_left = landmarks[mp_pose.PoseLandmark.MOUTH_LEFT]
        mouth_right = landmarks[mp_pose.PoseLandmark.MOUTH_RIGHT]
    except (AttributeError, IndexError):
        return base_sample, None

    upper_torso_visible = landmark_visible(left_shoulder) and landmark_visible(right_shoulder)
    if not upper_torso_visible:
        return {
            **base_sample,
            "pose_detected": True,
        }, None

    mouth_center = midpoint(mouth_left, mouth_right)
    mouth_point = type("Point", (), mouth_center)()

    left_to_mouth = distance_xy(left_wrist, mouth_point)
    right_to_mouth = distance_xy(right_wrist, mouth_point)
    hand_near_mouth = (
        left_to_mouth < HAND_NEAR_MOUTH_DISTANCE_THRESH
        or right_to_mouth < HAND_NEAR_MOUTH_DISTANCE_THRESH
    )

    shoulder_mid = midpoint(left_shoulder, right_shoulder)
    torso_center = (shoulder_mid["x"], shoulder_mid["y"])

    shoulder_tilt = abs(float(left_shoulder.y - right_shoulder.y))
    upper_torso_center_offset_x = float(torso_center[0] - 0.5)
    upper_torso_center_offset_y = float(torso_center[1] - 0.5)
    upper_torso_center_shift = math.hypot(upper_torso_center_offset_x, upper_torso_center_offset_y)
    shoulder_width_ratio = abs(float(left_shoulder.x - right_shoulder.x))
    shoulder_line_angle = angle_deg(landmark_xy(left_shoulder), landmark_xy(right_shoulder))
    arm_asymmetry = abs(angle_deg(landmark_xy(left_shoulder), landmark_xy(left_wrist)))
    arm_asymmetry -= abs(angle_deg(landmark_xy(right_shoulder), landmark_xy(right_wrist)))
    arm_asymmetry = abs(arm_asymmetry)

    elevated_hands = (
        left_wrist.y < left_shoulder.y + ELEVATED_HAND_MARGIN
        or right_wrist.y < right_shoulder.y + ELEVATED_HAND_MARGIN
    )
    upper_torso_posture_shift = (
        shoulder_tilt > SHOULDER_TILT_THRESH
        or upper_torso_center_shift > UPPER_TORSO_CENTER_SHIFT_THRESH
        or shoulder_width_ratio < SHOULDER_WIDTH_NARROW_THRESH
    )

    movement = 0.0
    if previous_torso_center is not None:
        movement = math.hypot(
            torso_center[0] - previous_torso_center[0],
            torso_center[1] - previous_torso_center[1],
        )
    high_movement = movement > HIGH_MOVEMENT_THRESH

    sample = {
        "pose_detected": True,
        "upper_torso_visible": True,
        "hand_near_mouth": bool(hand_near_mouth),
        "upper_torso_posture_shift": bool(upper_torso_posture_shift),
        "elevated_hands": bool(elevated_hands),
        "high_movement": bool(high_movement),
        "arm_asymmetry_deg": round(float(arm_asymmetry), 2),
        "shoulder_line_angle_deg": round(float(shoulder_line_angle), 2),
        "shoulder_tilt": round(float(shoulder_tilt), 3),
        "upper_torso_center_offset_x": round(float(upper_torso_center_offset_x), 3),
        "upper_torso_center_offset_y": round(float(upper_torso_center_offset_y), 3),
        "upper_torso_center_shift": round(float(upper_torso_center_shift), 3),
        "shoulder_width_ratio": round(float(shoulder_width_ratio), 3),
        "torso_movement_delta": round(float(movement), 3),
    }
    return sample, torso_center


def _ratio(samples: List[Dict[str, Any]], key: str) -> float:
    if not samples:
        return 0.0
    return round(sum(1 for sample in samples if bool(sample.get(key, False))) / len(samples), 3)


def _mean_numeric(samples: List[Dict[str, Any]], key: str) -> Optional[float]:
    values = [
        float(sample[key])
        for sample in samples
        if isinstance(sample.get(key), (int, float)) and not isinstance(sample.get(key), bool)
    ]
    if not values:
        return None
    return round(sum(values) / len(values), 3)


def summarize_segment(samples: List[Dict[str, Any]]) -> Dict[str, Any]:
    pose_samples = [sample for sample in samples if bool(sample.get("pose_detected", False))]
    upper_torso_samples = [
        sample for sample in pose_samples if bool(sample.get("upper_torso_visible", False))
    ]
    return {
        "sample_count": len(samples),
        "pose_detected_ratio": _ratio(samples, "pose_detected"),
        "upper_torso_visible_ratio": _ratio(samples, "upper_torso_visible"),
        "hand_near_mouth_ratio": _ratio(samples, "hand_near_mouth"),
        "upper_torso_posture_shift_ratio": _ratio(samples, "upper_torso_posture_shift"),
        "elevated_hands_ratio": _ratio(samples, "elevated_hands"),
        "high_movement_ratio": _ratio(samples, "high_movement"),
        "mean_upper_torso_center_shift": _mean_numeric(
            upper_torso_samples,
            "upper_torso_center_shift",
        ),
        "mean_torso_movement_delta": _mean_numeric(upper_torso_samples, "torso_movement_delta"),
        "mean_shoulder_tilt": _mean_numeric(upper_torso_samples, "shoulder_tilt"),
        "mean_shoulder_width_ratio": _mean_numeric(upper_torso_samples, "shoulder_width_ratio"),
    }


def write_segment(
    out_dir: Path,
    video_path: Path,
    segment_index: int,
    segment_start_sec: float,
    segment_end_sec: float,
    target_fps: float,
    samples: List[Dict[str, Any]],
) -> Path:
    segment_id = segment_name(segment_index)
    out_path = out_dir / f"posture_segment_{segment_index + 1:02d}.json"
    payload = {
        "video": video_path.name,
        "segment_id": segment_id,
        "segment_start_sec": round(segment_start_sec, 3),
        "segment_end_sec": round(segment_end_sec, 3),
        "target_fps": target_fps,
        "thresholds": {
            "hand_near_mouth_distance": HAND_NEAR_MOUTH_DISTANCE_THRESH,
            "upper_torso_visibility": UPPER_TORSO_VISIBILITY_THRESH,
            "shoulder_tilt": SHOULDER_TILT_THRESH,
            "upper_torso_center_shift": UPPER_TORSO_CENTER_SHIFT_THRESH,
            "shoulder_width_narrow": SHOULDER_WIDTH_NARROW_THRESH,
            "elevated_hand_margin": ELEVATED_HAND_MARGIN,
            "high_movement": HIGH_MOVEMENT_THRESH,
        },
        "summary": summarize_segment(samples),
        "samples": samples,
    }
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return out_path


def process_video(
    video_path: Path,
    output_dir: Path,
    *,
    segment_length_sec: float = DEFAULT_SEGMENT_LENGTH_SEC,
    target_fps: float = DEFAULT_TARGET_FPS,
    sample_every: Optional[int] = None,
    min_detection_confidence: float = 0.5,
    min_tracking_confidence: float = 0.5,
    clean_output: bool = True,
) -> List[Path]:
    ensure_dependencies()

    video_path = Path(video_path)
    output_dir = Path(output_dir)

    if not video_path.exists():
        raise FileNotFoundError(f"Video not found: {video_path}")
    if segment_length_sec <= 0:
        raise ValueError("segment_length_sec must be greater than zero")
    if target_fps <= 0:
        raise ValueError("target_fps must be greater than zero")
    if sample_every is not None and sample_every < 1:
        raise ValueError("sample_every must be 1 or greater")

    output_dir.mkdir(parents=True, exist_ok=True)
    if clean_output:
        removed = clean_previous_outputs(output_dir)
        if removed:
            print(f"[clean] Removed {removed} old posture segment file(s) from {output_dir}")

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Could not open video file {video_path}.")

    video_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frame_stride = sample_every or max(1, round(video_fps / target_fps))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    duration_sec = total_frames / video_fps if video_fps > 0 else 0.0

    print(
        f"[info] Processing {video_path.name} -> {output_dir} "
        f"({duration_sec / 60.0:.2f} min, source FPS {video_fps:.2f}, stride {frame_stride})"
    )

    mp_pose = mp.solutions.pose
    current_segment_index: Optional[int] = None
    current_samples: List[Dict[str, Any]] = []
    written_files: List[Path] = []
    frame_idx = 0
    processed_frames = 0
    pose_detected_frames = 0
    previous_torso_center: Optional[Tuple[float, float]] = None

    try:
        with mp_pose.Pose(
            static_image_mode=False,
            model_complexity=1,
            smooth_landmarks=True,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        ) as pose:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                frame_idx += 1
                if frame_idx % frame_stride != 0:
                    continue

                processed_frames += 1
                timestamp_sec = (frame_idx - 1) / video_fps
                segment_index = int(timestamp_sec // segment_length_sec)
                segment_start_time = segment_index * segment_length_sec
                segment_time_sec = timestamp_sec - segment_start_time

                if current_segment_index is None:
                    current_segment_index = segment_index
                elif segment_index != current_segment_index:
                    written_files.append(
                        write_segment(
                            output_dir,
                            video_path,
                            current_segment_index,
                            current_segment_index * segment_length_sec,
                            timestamp_sec,
                            target_fps,
                            current_samples,
                        )
                    )
                    current_samples = []
                    current_segment_index = segment_index

                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                pose_results = pose.process(frame_rgb)
                posture_features, previous_torso_center = compute_posture_sample(
                    pose_results.pose_landmarks,
                    mp_pose,
                    previous_torso_center=previous_torso_center,
                )

                if posture_features["pose_detected"]:
                    pose_detected_frames += 1

                sample = {
                    "segment_id": segment_name(segment_index),
                    "timestamp_sec": round(timestamp_sec, 3),
                    "segment_time_sec": round(segment_time_sec, 3),
                }
                sample.update(posture_features)
                current_samples.append(sample)
    finally:
        cap.release()

    if current_segment_index is not None and current_samples:
        written_files.append(
            write_segment(
                output_dir,
                video_path,
                current_segment_index,
                current_segment_index * segment_length_sec,
                duration_sec,
                target_fps,
                current_samples,
            )
        )

    pose_rate = pose_detected_frames / processed_frames if processed_frames else 0.0
    print(
        f"[done] {video_path.name}: {len(written_files)} segment file(s), "
        f"{processed_frames} sampled frame(s), pose detected in {pose_rate:.1%}"
    )
    return written_files


def find_video_files(video: Optional[str], video_dir: Optional[str], exam_id: Optional[str]) -> List[Path]:
    if video:
        return [Path(video)]

    search_dir = Path(video_dir or DEFAULT_VIDEO_DIR)
    if not search_dir.exists():
        raise FileNotFoundError(
            f"Video directory not found: {search_dir}. "
            "Pass --video or point --video-dir to your external DATA_COLLECTED_VIDEOS folder."
        )

    videos = sorted(search_dir.glob("*.mp4"))
    if exam_id:
        target_name = f"{exam_id}.mp4"
        videos = [path for path in videos if path.name.lower() == target_name.lower()]

    if not videos:
        label = f" matching {exam_id}" if exam_id else ""
        raise FileNotFoundError(f"No MP4 video files{label} found in {search_dir}")

    return videos


def default_output_dir(video_path: Path, output_root: Path) -> Path:
    video_stem = Path(video_path).stem
    return Path(output_root) / video_stem / f"{video_stem}-posture_outputs"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Extract posture-only features into standalone segmented JSON artifacts. "
            "Default output is EXAM-PXX/EXAM-PXX-posture_outputs/."
        )
    )
    parser.add_argument("--video", help="Path to one MP4 file, e.g. DATA_COLLECTED_VIDEOS/EXAM-P01.mp4")
    parser.add_argument(
        "--video-dir",
        default=None,
        help=f"Folder containing MP4 files. Defaults to {DEFAULT_VIDEO_DIR} when --video is omitted.",
    )
    parser.add_argument("--exam-id", help="Optional exam ID filter, e.g. EXAM-P01")
    parser.add_argument(
        "--out",
        default=None,
        help="Output folder for single-video runs. For batch runs, use --output-root instead.",
    )
    parser.add_argument(
        "--output-root",
        default=".",
        help="Root where EXAM-PXX/EXAM-PXX-posture_outputs folders will be created.",
    )
    parser.add_argument("--segment-length-sec", type=float, default=DEFAULT_SEGMENT_LENGTH_SEC)
    parser.add_argument("--target-fps", type=float, default=DEFAULT_TARGET_FPS)
    parser.add_argument(
        "--sample-every",
        type=int,
        default=None,
        help="Process every Nth frame. Overrides --target-fps when supplied.",
    )
    parser.add_argument("--min-detection-confidence", type=float, default=0.5)
    parser.add_argument("--min-tracking-confidence", type=float, default=0.5)
    parser.add_argument("--no-clean", action="store_true", help="Keep old posture_segment_*.json files.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    videos = find_video_files(args.video, args.video_dir, args.exam_id)

    if args.out and len(videos) > 1:
        raise ValueError("--out can only be used with one video. Use --output-root for batch runs.")

    written_files: List[Path] = []
    for video_path in videos:
        output_dir = Path(args.out) if args.out else default_output_dir(video_path, Path(args.output_root))
        written_files.extend(
            process_video(
                video_path,
                output_dir,
                segment_length_sec=args.segment_length_sec,
                target_fps=args.target_fps,
                sample_every=args.sample_every,
                min_detection_confidence=args.min_detection_confidence,
                min_tracking_confidence=args.min_tracking_confidence,
                clean_output=not args.no_clean,
            )
        )

    print(f"\nDone! Saved {len(written_files)} posture segment file(s).")


if __name__ == "__main__":
    main()
