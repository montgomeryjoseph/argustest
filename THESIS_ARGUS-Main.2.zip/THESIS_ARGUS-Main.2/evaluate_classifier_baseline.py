from __future__ import annotations

import argparse
import csv
import json
import math
import platform
from pathlib import Path
from statistics import mean
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

try:
    import numpy as np
    import pandas as pd
    import sklearn
    from sklearn.impute import SimpleImputer
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import (
        accuracy_score,
        balanced_accuracy_score,
        confusion_matrix,
        f1_score,
        precision_score,
        recall_score,
        roc_auc_score,
    )
    from sklearn.model_selection import LeaveOneGroupOut
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
except ImportError as exc:
    raise RuntimeError(
        "Missing baseline dependencies. Install them with: "
        "py -m pip install pandas numpy scikit-learn"
    ) from exc


MEAN_FEATURE_KEYS = {
    "face_present_ratio_mean": "face_present_ratio",
    "pose_success_ratio_mean": "pose_success_ratio",
    "face_center_offset_abs_mean": "face_center_offset_abs",
    "face_bbox_area_ratio_mean": "face_bbox_area_ratio",
    "head_offscreen_ratio_mean": "head_offscreen_ratio",
    "mouth_activity_ratio_mean": "mouth_activity_ratio",
    "gaze_detected_ratio_mean": "gaze_detected_ratio",
    "gaze_offscreen_ratio_mean": "gaze_offscreen_ratio",
    "pose_detected_ratio_mean": "pose_detected_ratio",
    "upper_torso_visible_ratio_mean": "upper_torso_visible_ratio",
    "hand_near_mouth_ratio_mean": "hand_near_mouth_ratio",
    "elevated_hands_ratio_mean": "elevated_hands_ratio",
    "upper_torso_posture_shift_ratio_mean": "upper_torso_posture_shift_ratio",
    "high_movement_ratio_mean": "high_movement_ratio",
    "upper_torso_center_shift_mean": "upper_torso_center_shift",
    "torso_movement_delta_mean": "torso_movement_delta",
    "shoulder_width_ratio_mean": "shoulder_width_ratio",
}

ABS_MEAN_FEATURE_KEYS = {
    "head_yaw_abs_deg_mean": "head_yaw_deg",
    "head_roll_abs_deg_mean": "head_roll_deg",
    "gaze_angle_abs_deg_mean": "gaze_angle_deg",
    "arm_asymmetry_abs_deg_mean": "arm_asymmetry_deg",
    "shoulder_line_angle_abs_deg_mean": "shoulder_line_angle_deg",
}

MAX_FEATURE_KEYS = {
    "face_absence_duration_sec_max": "face_absence_duration_sec",
    "head_offscreen_duration_sec_max": "head_offscreen_duration_sec",
    "gaze_offscreen_duration_sec_max": "gaze_offscreen_duration_sec",
}

MODEL_FEATURES = (
    "head_yaw_abs_deg_mean",
    "mouth_activity_ratio_mean",
    "gaze_angle_abs_deg_mean",
    "upper_torso_center_shift_mean",
    "torso_movement_delta_mean",
)
MODEL_REGULARIZATION_C = 0.03


def _as_float(value: Any) -> Optional[float]:
    if value is None or isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _feature_values(
    events: Sequence[Mapping[str, Any]],
    key: str,
) -> List[float]:
    values: List[float] = []
    for event in events:
        features = event.get("features", {})
        if not isinstance(features, Mapping):
            continue
        value = _as_float(features.get(key))
        if value is not None:
            values.append(value)
    return values


def _folded_pitch_deviation(value: float) -> float:
    """Treat either 0 or 180 degrees as a possible solvePnP frontal convention."""
    wrapped = ((value + 180.0) % 360.0) - 180.0
    return min(abs(wrapped), 180.0 - abs(wrapped))


def extract_segment_features(data: Mapping[str, Any]) -> Dict[str, float]:
    events = [
        event
        for event in data.get("events", [])
        if isinstance(event, Mapping)
    ]
    if not events:
        raise ValueError("MBIE segment contains no fused events.")

    result: Dict[str, float] = {}
    for output_name, source_key in MEAN_FEATURE_KEYS.items():
        values = _feature_values(events, source_key)
        result[output_name] = mean(values) if values else math.nan

    for output_name, source_key in ABS_MEAN_FEATURE_KEYS.items():
        values = [abs(value) for value in _feature_values(events, source_key)]
        result[output_name] = mean(values) if values else math.nan

    for output_name, source_key in MAX_FEATURE_KEYS.items():
        values = _feature_values(events, source_key)
        result[output_name] = max(values) if values else math.nan

    pitch_values = [
        _folded_pitch_deviation(value)
        for value in _feature_values(events, "head_pitch_deg")
    ]
    result["head_pitch_deviation_deg_mean"] = (
        mean(pitch_values) if pitch_values else math.nan
    )

    modality_seconds = {"face_head": 0, "gaze": 0, "posture": 0}
    for event in events:
        available = event.get("available_modalities", [])
        if not isinstance(available, list):
            continue
        for modality in modality_seconds:
            if modality in available:
                modality_seconds[modality] += 1
    seconds = len(events)
    for modality, count in modality_seconds.items():
        result[f"{modality}_availability_ratio"] = count / seconds

    return {
        key: round(value, 6) if math.isfinite(value) else value
        for key, value in result.items()
    }


def normalize_label(value: str) -> int:
    normalized = value.strip().lower().replace("-", "_").replace(" ", "_")
    if normalized in {"cheating", "suspicious", "suspicion_of_cheating"}:
        return 1
    if normalized in {"non_cheating", "not_cheating", "non_suspicious"}:
        return 0
    raise ValueError(f"Unsupported label: {value!r}")


def segment_suffix(value: str) -> str:
    text = value.strip().lower().replace("segment_", "")
    try:
        return f"{int(text):02d}"
    except ValueError as exc:
        raise ValueError(f"Invalid segment_id: {value!r}") from exc


def load_label_rows(path: Path) -> List[Dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError(f"Label CSV contains no data rows: {path}")

    required = {"video_id", "segment_id", "label"}
    missing = required.difference(rows[0])
    if missing:
        raise ValueError(f"Label CSV is missing columns: {sorted(missing)}")

    seen_segments = set()
    for row in rows:
        key = (str(row["video_id"]).strip(), segment_suffix(str(row["segment_id"])))
        if key in seen_segments:
            raise ValueError(
                f"Duplicate label row for {key[0]} segment_{key[1]} in {path}"
            )
        seen_segments.add(key)
        normalize_label(str(row["label"]))
    return rows


def load_training_table(
    input_root: Path,
    label_rows: Sequence[Mapping[str, str]],
) -> Tuple[List[Dict[str, Any]], List[str]]:
    dataset: List[Dict[str, Any]] = []
    missing_files: List[str] = []

    for label_row in label_rows:
        video_id = str(label_row["video_id"]).strip()
        suffix = segment_suffix(str(label_row["segment_id"]))
        mbie_path = (
            input_root
            / video_id
            / f"{video_id}_MBIE_outputs"
            / f"mbie_segment_{suffix}.json"
        )
        if not mbie_path.is_file():
            missing_files.append(str(mbie_path))
            continue

        try:
            data = json.loads(mbie_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {mbie_path}: {exc}") from exc
        if not isinstance(data, dict):
            raise ValueError(f"Expected a JSON object in {mbie_path}")
        if data.get("schema_version") != 3:
            raise ValueError(
                f"Expected MBIE schema_version 3 in {mbie_path}. "
                "Regenerate MBIE outputs before evaluation."
            )

        participant_id = str(label_row.get("participant_id", "")).strip()
        group_id = participant_id or video_id
        row: Dict[str, Any] = {
            "video_id": video_id,
            "segment_id": f"segment_{suffix}",
            "group_id": group_id,
            "participant_role": str(label_row.get("participant_role", "")).strip(),
            "label_text": str(label_row["label"]).strip(),
            "label": normalize_label(str(label_row["label"])),
            "source_file": str(mbie_path),
        }
        row.update(extract_segment_features(data))
        dataset.append(row)

    return dataset, missing_files


def metric_summary(
    y_true: Any,
    y_pred: Any,
    y_score: Any,
) -> Dict[str, Any]:
    matrix = confusion_matrix(y_true, y_pred, labels=[0, 1])
    true_negative, false_positive, _, _ = matrix.ravel()
    negative_count = true_negative + false_positive
    summary: Dict[str, Any] = {
        "accuracy": round(float(accuracy_score(y_true, y_pred)), 4),
        "balanced_accuracy": round(
            float(balanced_accuracy_score(y_true, y_pred)),
            4,
        ),
        "precision": round(
            float(precision_score(y_true, y_pred, zero_division=0)),
            4,
        ),
        "recall": round(
            float(recall_score(y_true, y_pred, zero_division=0)),
            4,
        ),
        "f1": round(float(f1_score(y_true, y_pred, zero_division=0)), 4),
        "false_positive_rate": (
            round(float(false_positive / negative_count), 4)
            if negative_count
            else None
        ),
        "confusion_matrix": matrix.tolist(),
    }
    if len(set(int(value) for value in y_true)) == 2:
        summary["roc_auc"] = round(float(roc_auc_score(y_true, y_score)), 4)
    else:
        summary["roc_auc"] = None
    return summary


def new_pipeline() -> Any:
    return Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            (
                "classifier",
                LogisticRegression(
                    C=MODEL_REGULARIZATION_C,
                    class_weight="balanced",
                    max_iter=5000,
                    random_state=42,
                ),
            ),
        ]
    )


def aggregate_group_features(
    dataframe: Any,
    feature_columns: Sequence[str],
) -> Any:
    records: List[Dict[str, Any]] = []
    for group_id, group in dataframe.groupby("group_id", sort=True):
        labels = group["label"].astype(int).unique()
        if len(labels) != 1:
            raise ValueError(f"Conflicting labels found for group {group_id}.")

        record: Dict[str, Any] = {
            "group_id": str(group_id),
            "video_ids": "|".join(sorted(set(group["video_id"].astype(str)))),
            "label_text": str(group["label_text"].iloc[0]),
            "label": int(labels[0]),
            "segments": int(len(group)),
        }
        for feature in feature_columns:
            values = pd.to_numeric(group[feature], errors="coerce")
            record[feature] = float(values.mean()) if values.notna().any() else math.nan
        records.append(record)
    return pd.DataFrame(records)


def evaluate_baseline(
    group_dataframe: Any,
    feature_columns: Sequence[str],
) -> Dict[str, Any]:
    x_values = group_dataframe[list(feature_columns)]
    y_values = group_dataframe["label"].astype(int).to_numpy()
    groups = group_dataframe["group_id"].astype(str).to_numpy()
    logo = LeaveOneGroupOut()
    scores = np.full(len(group_dataframe), np.nan, dtype=float)

    fold_records: List[Dict[str, Any]] = []
    for train_indices, test_indices in logo.split(x_values, y_values, groups):
        train_labels = set(int(value) for value in y_values[train_indices])
        if len(train_labels) < 2:
            raise ValueError(
                "A leave-one-group-out training fold contains only one class. "
                "More independent videos are required."
            )
        pipeline = new_pipeline()
        pipeline.fit(
            x_values.iloc[train_indices],
            y_values[train_indices],
        )
        fold_scores = pipeline.predict_proba(x_values.iloc[test_indices])[:, 1]
        scores[test_indices] = fold_scores
        fold_records.append(
            {
                "held_out_group": str(groups[test_indices][0]),
                "training_groups": int(len(train_indices)),
                "test_groups": int(len(test_indices)),
            }
        )

    predictions = (scores >= 0.5).astype(int)
    group_metrics = metric_summary(
        y_values,
        predictions,
        scores,
    )

    prediction_table = group_dataframe[
        ["group_id", "video_ids", "label_text", "label", "segments"]
    ].copy()
    prediction_table["positive_score"] = scores
    prediction_table["predicted_label"] = predictions

    group_predictions: List[Dict[str, Any]] = []
    for row in prediction_table.to_dict(orient="records"):
        group_predictions.append(
            {
                "group_id": str(row["group_id"]),
                "video_ids": str(row["video_ids"]).split("|"),
                "label": int(row["label"]),
                "positive_score": round(float(row["positive_score"]), 6),
                "predicted_label": int(row["predicted_label"]),
                "segments": int(row["segments"]),
            }
        )

    return {
        "group_metrics": group_metrics,
        "group_predictions": group_predictions,
        "folds": fold_records,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate an independent Logistic Regression baseline using "
            "leave-one-participant/video-out predictions."
        )
    )
    parser.add_argument(
        "--input-root",
        default=".",
        help="Folder containing EXAM-PXX output folders. Default: current folder.",
    )
    parser.add_argument(
        "--labels",
        default="exam_labels.csv",
        help="Segment-label CSV. Default: exam_labels.csv",
    )
    parser.add_argument(
        "--output-dir",
        default="baseline_results",
        help="Evaluation output folder. Default: baseline_results",
    )
    parser.add_argument(
        "--expected-groups",
        type=int,
        default=12,
        help="Expected independent participants/videos. Default: 12.",
    )
    parser.add_argument(
        "--allow-missing",
        action="store_true",
        help=(
            "Evaluate available labeled segments even when some MBIE files are "
            "missing. By default, missing labeled segments stop evaluation."
        ),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    input_root = Path(args.input_root)
    label_path = Path(args.labels)
    label_rows = load_label_rows(label_path)
    dataset, missing_files = load_training_table(input_root, label_rows)
    if not dataset:
        raise FileNotFoundError(
            "No labeled MBIE segment files were found. Run mbie_vector_fusion.py "
            "for every labeled EXAM-PXX video first."
        )
    if missing_files and not args.allow_missing:
        examples = "\n".join(f"  - {path}" for path in missing_files[:5])
        raise FileNotFoundError(
            f"{len(missing_files)} labeled MBIE segment file(s) are missing. "
            "Generate them before evaluation or pass --allow-missing to run an "
            f"incomplete exploratory analysis.\n{examples}"
        )

    dataframe = pd.DataFrame(dataset)
    unavailable_features = [
        feature for feature in MODEL_FEATURES if feature not in dataframe.columns
    ]
    all_missing_features = [
        feature
        for feature in MODEL_FEATURES
        if feature in dataframe.columns and dataframe[feature].isna().all()
    ]
    feature_columns = [
        feature
        for feature in MODEL_FEATURES
        if feature in dataframe.columns and feature not in all_missing_features
    ]
    if not feature_columns:
        raise ValueError("No usable numeric MBIE features were extracted.")

    labels_per_group = dataframe.groupby("group_id")["label"].nunique()
    inconsistent_groups = labels_per_group[labels_per_group > 1].index.tolist()
    if inconsistent_groups:
        raise ValueError(
            "Each evaluation group must have one video-level label. Conflicting "
            f"labels were found for: {inconsistent_groups}"
        )

    group_count = int(dataframe["group_id"].nunique())
    class_group_counts = (
        dataframe[["group_id", "label"]]
        .drop_duplicates()
        .groupby("label")["group_id"]
        .nunique()
        .to_dict()
    )
    if len(class_group_counts) < 2:
        raise ValueError("Both cheating and non_cheating groups are required.")

    role_label_pairs = dataframe[["participant_role", "label"]].drop_duplicates()
    role_leakage_warning = bool(
        role_label_pairs["participant_role"].ne("").all()
        and role_label_pairs.groupby("participant_role")["label"].nunique().max() == 1
    )

    group_dataframe = aggregate_group_features(dataframe, feature_columns)
    evaluation = evaluate_baseline(group_dataframe, feature_columns)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    feature_table_path = output_dir / "baseline_feature_table.csv"
    dataframe.to_csv(feature_table_path, index=False)
    group_feature_table_path = output_dir / "baseline_group_feature_table.csv"
    group_dataframe.to_csv(group_feature_table_path, index=False)
    group_predictions_path = output_dir / "baseline_group_predictions.csv"
    pd.DataFrame(evaluation["group_predictions"]).to_csv(
        group_predictions_path,
        index=False,
    )

    result = {
        "evaluation_schema_version": 3,
        "model": "LogisticRegression",
        "purpose": "conventional evaluation baseline only",
        "validation": "leave_one_group_out",
        "decision_threshold": 0.5,
        "primary_unit_of_analysis": "independent participant/video group",
        "score_notice": (
            "positive_score is an uncalibrated Logistic Regression baseline score, "
            "not a true probability and not the production MLLM decision."
        ),
        "software": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scikit_learn": sklearn.__version__,
        },
        "methodology": {
            "preprocessing": (
                "Median imputation and standardization fitted inside each "
                "leave-one-group-out training fold."
            ),
            "classifier": (
                "Strongly regularized L2 Logistic Regression with C=0.03, "
                "class_weight='balanced', and a 0.5 decision threshold."
            ),
            "aggregation": (
                "One-minute MBIE features are averaged into one row per "
                "participant/video before model fitting and evaluation."
            ),
            "feature_selection": (
                "Five continuous, thesis-defined multimodal measurements are used "
                "to reduce overfitting and dependence on extractor thresholds."
            ),
        },
        "dataset": {
            "labeled_csv_rows": len(label_rows),
            "evaluated_segments": len(dataframe),
            "independent_groups": group_count,
            "expected_groups": args.expected_groups,
            "class_group_counts": {
                "non_cheating": int(class_group_counts.get(0, 0)),
                "cheating": int(class_group_counts.get(1, 0)),
            },
            "missing_mbie_files": missing_files,
        },
        "leakage_controls": {
            "group_column": "participant_id when supplied, otherwise video_id",
            "participant_role_excluded": True,
            "video_and_segment_ids_excluded": True,
            "timestamps_excluded": True,
            "mbie_cue_strength_excluded": True,
            "one_row_per_evaluation_group": True,
        },
        "quality_and_context_features_excluded": [
            "pose_success_ratio_mean",
            "gaze_detected_ratio_mean",
            "pose_detected_ratio_mean",
            "upper_torso_visible_ratio_mean",
            "face_head_availability_ratio",
            "gaze_availability_ratio",
            "posture_availability_ratio",
            "face_bbox_area_ratio_mean",
            "shoulder_width_ratio_mean",
            "shoulder_line_angle_abs_deg_mean",
        ],
        "threshold_derived_features_excluded": [
            "head_offscreen_ratio_mean",
            "head_offscreen_duration_sec_max",
            "gaze_offscreen_ratio_mean",
            "gaze_offscreen_duration_sec_max",
            "upper_torso_posture_shift_ratio_mean",
            "high_movement_ratio_mean",
        ],
        "warnings": [
            (
                f"Only {group_count} independent groups were evaluated; "
                f"{args.expected_groups} were expected."
            )
            if group_count != args.expected_groups
            else None,
            (
                "participant_role maps directly to the label in the available data. "
                "It was excluded because using it would leak the answer."
            )
            if role_leakage_warning
            else None,
            (
                "Ground truth is assigned at the participant/video level. Segment "
                "features are therefore aggregated before model fitting to avoid "
                "treating repeated labels as independent observations."
            ),
            (
                "With approximately 12 independent videos, results are preliminary "
                "proof-of-concept evidence and should not be presented as population-level "
                "performance."
            ),
            (
                "The current model specification was refined during development on "
                "this dataset. Confirm the reported performance on newly collected, "
                "untouched participants before treating it as final validation."
            ),
        ],
        "features": feature_columns,
        "all_missing_features_removed": all_missing_features,
        "unavailable_features_removed": unavailable_features,
        **evaluation,
    }
    result["warnings"] = [warning for warning in result["warnings"] if warning]

    result_path = output_dir / "logistic_regression_leave_one_group_out.json"
    result_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"[done] Baseline feature table: {feature_table_path}")
    print(f"[done] Group feature table: {group_feature_table_path}")
    print(f"[done] Group predictions: {group_predictions_path}")
    print(f"[done] Baseline evaluation: {result_path}")
    if group_count != args.expected_groups:
        print(
            f"[warn] Evaluated {group_count} independent group(s); "
            f"expected {args.expected_groups}."
        )
    if missing_files:
        print(f"[warn] Missing {len(missing_files)} labeled MBIE segment file(s).")


if __name__ == "__main__":
    main()
