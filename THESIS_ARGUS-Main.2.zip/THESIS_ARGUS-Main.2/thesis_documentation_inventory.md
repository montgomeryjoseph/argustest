# ARGUS-Lite Thesis Documentation Inventory

This file identifies the repository artifacts that are relevant to the thesis.
It does not replace the thesis manuscript. Use it as a source map when updating
the latest document.

## Evaluation Scope

- Unit of analysis: one independent participant/video session.
- Labeled sessions: 11 (`EXAM-P01` through `EXAM-P11`).
- Ground-truth composition: 6 suspicious-group sessions and 5
  non-suspicious-group sessions.
- Proposed-system decisions: archived Qwen3.7-Plus and OpenAI-o3 outputs.
- Shared inference prompt: ARGUS-Lite Behavioral Risk Report Prompt v1.3.
- Evaluation labels and participant roles were withheld from the LLMs and used
  only after inference.
- `Suspicious behavior` is an evaluation/screening label and does not prove
  cheating, intent, communication, or misconduct.

The source CSV still uses `cheating` and `non_cheating` as experimental labels.
The evaluation scripts display them as `Suspicious behavior` and
`Non-suspicious behavior`, respectively.

## Methods Sources

| Artifact | Thesis use |
|---|---|
| `face_head_orientation_extractor_segmented.py` | Face/head feature-extraction implementation and thresholds |
| `gaze_tracker.py` | Gaze feature-extraction implementation and thresholds |
| `posture_detector.py` | Visible upper-torso feature-extraction implementation and thresholds |
| `mbie_vector_fusion.py` | Neutral temporal alignment, rule-based cue fusion, and compact LLM input generation |
| `exam_labels.csv` | Evaluation-only session labels, participant roles, source FPS, and represented duration |
| `output_generation/<model>/EXAM-PXX/prompt.txt` | Exact prompt v1.3 supplied during inference |
| `output_generation/<model>/EXAM-PXX/run_metadata.txt` | Model/run provenance and MBIE input record |
| `evaluate_llm_outputs.py` | Reproducible proposed-system evaluation procedure |
| `evaluate_classifier_baseline.py` | Leave-one-group-out conventional baseline procedure |

The video folder is not required to rerun LLM-output evaluation. It is required
only when regenerating extractor outputs. The conventional baseline requires
the existing MBIE outputs and labels, while the notebook requires the generated
`baseline_results/` files.

## Primary Quantitative Results

Use session-level results as the primary quantitative evidence. Do not treat
one-minute segments as independent participants.

| Model | TN | FP | FN | TP | Accuracy | Balanced accuracy | Precision | Recall | Specificity | F1 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Qwen3.7-Plus | 1 | 4 | 2 | 4 | 0.4545 | 0.4333 | 0.5000 | 0.6667 | 0.2000 | 0.5714 |
| OpenAI-o3 | 0 | 5 | 1 | 5 | 0.4545 | 0.4167 | 0.5000 | 0.8333 | 0.0000 | 0.6250 |
| Logistic Regression baseline | 4 | 1 | 1 | 5 | 0.8182 | 0.8167 | 0.8333 | 0.8333 | 0.8000 | 0.8333 |

Both LLMs evaluated all 11 sessions with no abstentions. Their 95% Wilson
accuracy interval is approximately 0.213 to 0.720. The wide interval reflects
the very small sample and should be reported with the point estimate.

Primary tables and machine-readable summaries:

- `llm_evaluation_results/llm_model_metrics.csv`
- `llm_evaluation_results/llm_session_predictions.csv`
- `llm_evaluation_results/model_metric_comparison.csv`
- `llm_evaluation_results/llm_evaluation_summary.json`
- `llm_evaluation_results/llm_evaluation_summary.txt`
- `baseline_results/logistic_regression_leave_one_group_out.json`
- `baseline_results/baseline_group_predictions.csv`

Primary figures:

- `llm_evaluation_results/figures/llm_confusion_matrices.png`
- `llm_evaluation_results/figures/model_metric_comparison.png`
- `llm_evaluation_results/figures/session_prediction_map.png`
- `thesis_figures/baseline_group_confusion_matrix.png`

Suggested caption for the LLM confusion figure: "Session-level confusion
matrices for Qwen3.7-Plus and OpenAI-o3 using the fixed ARGUS-Lite prompt v1.3.
Rows represent evaluation ground truth and columns represent archived LLM
predictions."

Suggested caption for the comparison figure: "Session-level evaluation metrics
for two archived LLM reasoning runs and the leave-one-group-out Logistic
Regression baseline. Results are preliminary because only 11 independent
sessions were available."

## Agreement and Error Analysis

The LLMs agreed on 9 of 11 sessions (agreement 0.8182; Cohen's kappa 0.4211).
They disagreed on `EXAM-P05` and `EXAM-P06`. Each model was correct on one of
those two sessions, so the exact McNemar comparison of paired correctness is
`p = 1.0`. This does not establish equivalence; the sample is too small to
detect a meaningful difference reliably.

Use these files for the Results and Discussion chapters:

- `llm_evaluation_results/llm_pairwise_agreement.csv`
- `llm_evaluation_results/llm_disagreements.csv`
- `llm_evaluation_results/llm_error_analysis.csv`
- `llm_evaluation_results/session_prediction_comparison.csv`

The error pattern is more informative than accuracy alone. Qwen produced four
false positives and OpenAI-o3 produced five, corresponding to specificity of
0.20 and 0.00. This indicates a strong tendency to flag non-suspicious sessions
and should be discussed as a false-alarm and calibration limitation.

## Exploratory Notebook Material

The notebook figures were visually inspected and are not clipped. Their roles
are deliberately different:

| Figure | Appropriate use |
|---|---|
| `thesis_figures/selected_behavior_features_by_label.png` | Exploratory description of feature distributions; segment rows are correlated within a video |
| `thesis_figures/feature_correlation_matrix.png` | Exploratory assessment of relationships and redundant feature tendencies |
| `thesis_figures/pca_behavior_features.png` | Exploratory visualization of one-minute fused feature rows; not a participant-level accuracy result |
| `thesis_figures/baseline_group_confusion_matrix.png` | Primary session-level conventional-baseline result |

Do not use the distribution, correlation, or PCA figures to claim independent
sample size equal to the number of minute segments. The participant/video is
the independent unit.

## Audit and Appendix Material

Each archived LLM run contains exactly four files:

1. PDF Behavioral Risk Report.
2. Machine-readable evaluation record.
3. Exact prompt text.
4. Run metadata.

The 22 PDFs are qualitative report outputs and provenance artifacts. They may
be summarized in the main text and listed or sampled in an appendix. The JSON
records are the source of the quantitative classifications; the PDFs should not
be manually reinterpreted into different labels after seeing ground truth.

## Required Limitations

- Only 11 independent sessions were evaluated.
- The same dataset was involved in development decisions, so current results
  are preliminary development results rather than untouched external validation.
- The LLM outputs contain categorical labels and ordinal evidence strength, not
  calibrated probabilities; therefore LLM ROC-AUC is not reported.
- The LLMs showed a substantial positive-class bias and high false-positive rate.
- Session labels do not contain independently annotated behavioral-event
  timestamps, so timestamp localization accuracy cannot yet be measured.
- Confederate status is experimental ground truth, not an observable behavior
  that the model should be asked to identify directly.
- Behavioral reports are screening aids requiring human review, not automatic
  disciplinary decisions.

## Exclude From Thesis Evidence

- `__pycache__/` and `.ipynb_checkpoints/` are generated caches, not evidence.
- `tmp/` is temporary working space.
- Raw extractor JSON screenshots may illustrate schema but should not replace
  generated aggregate tables or reproducible evaluation outputs.
- LLM `evidence_strength` must not be presented as percentage confidence.

## Suggested Thesis Placement

| Thesis section | Material |
|---|---|
| Methodology | Extractors, MBIE, fixed prompt v1.3, hidden-label protocol, run archive structure, and evaluation scripts |
| Results | LLM metric table, LLM confusion matrices, model comparison, session prediction map, agreement, and baseline metrics |
| Discussion | Positive-class bias, false positives, model disagreements, small-sample uncertainty, and conventional-baseline comparison |
| Appendix | Prompt v1.3, machine-readable schema, run metadata template, selected PDF reports, and detailed session tables |

Wait for the latest thesis manuscript before transferring this material into
its chapters, tables, captions, and references.
