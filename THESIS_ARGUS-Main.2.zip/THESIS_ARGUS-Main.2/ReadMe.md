# ARGUS — Anti-Cheating Detection for Online Exams

Multimodal behaviour inference pipeline that extracts **face/head orientation**,
**eye gaze**, and **upper-torso posture** features from recorded exam videos.
MBIE performs neutral temporal fusion. A separate MLLM stage performs behavioral
pattern recognition and qualitative classification.

## Architecture

```
Recorded Video
     │
     ├──→ face_head_orientation_extractor_segmented.py
     │         Head pose (yaw/pitch/roll), mouth movement, offscreen flag
     │
     ├──→ gaze_tracker.py
     │         Horizontal gaze angle, gaze region (center/left/right/offscreen)
     │
     ├──→ posture_detector.py
     │         Multiple faces, face absence, occlusion, hand-to-mouth,
    │         upper-torso posture shift, elevated hands, torso movement
     │
     └──→ mbie_vector_fusion.py
               Per-second fusion -> cue_strength -> compact MLLM input
```

All feature extractors output one-minute JSON segments. MBIE aligns them into
a neutral behavioral-cue timeline for the separate MLLM inference stage.

## Project Structure

```
THESIS_ARGUS/
|-- face_head_orientation_extractor_segmented.py   # Module 1: face/head extraction
|-- gaze_tracker.py                                 # Module 2: gaze extraction
|-- posture_detector.py                             # Module 3: upper-torso extraction
|-- mbie_vector_fusion.py                           # Module 4: neutral temporal fusion
|-- evaluate_llm_outputs.py                         # Archived LLM-result evaluation
|-- evaluate_classifier_baseline.py                 # Evaluation-only ML baseline
|-- argus_feature_analysis_full.ipynb               # Exploratory analysis notebook
|-- exam_labels.csv                                 # Evaluation-only ground truth
|-- output_generation/                              # Four archived files per LLM run
|-- llm_evaluation_results/                         # Reproducible LLM metrics and figures
|-- baseline_results/                               # Conventional-baseline results
|-- thesis_figures/                                 # Notebook figures
|-- DATA_COLLECTED_VIDEOS/                          # Optional external/local video folder
`-- ReadMe.md                                       # This file
```

## Installation

1. Install **Python 3.10+** from [python.org](https://python.org) (ensure "Add to PATH" is checked).
2. Install dependencies:
   ```bash
   py -m pip install mediapipe==0.10.14 opencv-python numpy "protobuf<5"
   ```

   Install the optional evaluation-baseline dependencies:

   ```bash
   py -m pip install pandas numpy scikit-learn matplotlib jupyter
   ```

## Modules

### 1. Face & Head Orientation Extractor

Extracts per-frame head pose and mouth metrics using MediaPipe FaceMesh + solvePnP.

```bash
py face_head_orientation_extractor_segmented.py --video-dir DATA_COLLECTED_VIDEOS --output-root
```

| Flag | Description | Default |
|---|---|---|
| `--video` | Path to input video | *(required)* |
| `--out` | Output folder name | `outputs/` |
| `--segment-length-sec` | Segment duration in seconds | `60` |
| `--sample-every` | Use every nth frame | `1` |

**Output** — `face_head_orientation_segment_XX.json` per segment:
```json
{
  "segment_id": "segment_01",
  "timestamp_sec": 0.0,
  "segment_time_sec": 0.0,
  "face_present": true,
  "pose_success": true,
  "mouth_movement": false,
  "face_center_offset_x": -0.153,
  "face_center_offset_y": -0.251,
  "face_bbox_area_ratio": 0.0622,
  "head_pose_yaw_deg": -27.46,
  "head_pose_pitch_deg": -168.75,
  "head_pose_roll_deg": -5.75,
  "head_offscreen": true
}
```

| Field | Meaning | Threshold / Rule |
|---|---|---|
| `segment_id` | Current segment label | Generated from `--segment-length-sec`, default `60` seconds |
| `timestamp_sec` | Time in seconds from the start of the full video | No threshold |
| `segment_time_sec` | Time in seconds from the start of the current segment | No threshold |
| `face_present` | FaceMesh detected a face | MediaPipe `min_detection_confidence`, default `0.5` |
| `pose_success` | Head pose was successfully estimated using facial landmarks and `solvePnP` | `true` only when OpenCV pose estimation succeeds |
| `mouth_movement` | Mouth opening is above the normalized mouth threshold | `mouth_open_thresh_norm = 0.03` |
| `face_center_offset_x` | Horizontal face position relative to frame center; `0` is centered, negative is left, positive is right | Extractor stores the value; MBIE uses combined face offset `>= 0.35` as `face_far_from_center` |
| `face_center_offset_y` | Vertical face position relative to frame center; `0` is centered, negative is up, positive is down | Extractor stores the value; MBIE combines it with `face_center_offset_x` |
| `face_bbox_area_ratio` | Approximate fraction of the full frame occupied by the detected face box | Extractor stores the value; MBIE uses `<= 0.04` as `face_bbox_small` |
| `head_pose_yaw_deg` | Horizontal head turn in degrees | Used by `head_offscreen` |
| `head_pose_pitch_deg` | Up/down head rotation in degrees | Stored as a feature; interpret carefully because pitch depends on camera and pose calibration |
| `head_pose_roll_deg` | Sideways head tilt in degrees | Stored as a feature |
| `head_offscreen` | Head yaw exceeded the offscreen threshold | `abs(head_pose_yaw_deg) > 25.0` |

These are feature-extraction outputs, not final cheating decisions. MBIE later
combines face/head, gaze, and posture features without assigning the final label.

### 2. Gaze Tracker

Estimates horizontal gaze direction from iris landmarks using MediaPipe FaceMesh (refine_landmarks).

```bash
py gaze_tracker.py --video-dir DATA_COLLECTED_VIDEOS --output-root .
```

| Flag | Description | Default |
|---|---|---|
| `--video` | Path to one MP4 file | *(optional)* |
| `--video-dir` | Folder containing MP4 files | `DATA_COLLECTED_VIDEOS` |
| `--exam-id` | Optional exam ID filter, e.g. `EXAM-P01` | *(optional)* |
| `--output-root` | Root where `EXAM-PXX/EXAM-PXX_gaze_segments/` is created | `.` |
| `--segment-length-sec` | Segment duration in seconds | `60` |
| `--target-fps` | Target sampling FPS | `15` |
| `--offscreen-angle-deg` | Gaze threshold for offscreen labelling | `12.0` |

**Output** — `gaze_segment_XX.json` per segment:
```json
{
  "video": "EXAM-P01.mp4",
  "segment_id": "segment_01",
  "segment_start_sec": 0.0,
  "segment_end_sec": 60.0,
  "target_fps": 15.0,
  "offscreen_angle_deg": 12.0,
  "center_angle_deg": 7.0,
  "events": [
    {
      "segment_id": "segment_01",
      "timestamp_sec": 0.0,
      "segment_time_sec": 0.0,
      "gaze_detected": true,
      "offscreen_dur_sec": 0.0,
      "gaze_angle_deg": 2.51,
      "left_eye_angle_deg": 2.43,
      "right_eye_angle_deg": 2.59,
      "left_eye_ratio": 0.042,
      "right_eye_ratio": 0.045,
      "gaze_region": "center"
    }
  ]
}
```

| Field | Meaning | Threshold / Rule |
|---|---|---|
| `video` | Source video filename | No threshold |
| `segment_id` | Current segment label | Generated from `--segment-length-sec`, default `60` seconds |
| `segment_start_sec` | Segment start time in the full video | No threshold |
| `segment_end_sec` | Segment end time in the full video | No threshold |
| `target_fps` | Target sampling rate used by the extractor | Default `15`; use `--target-fps 30` only when higher temporal detail is needed |
| `offscreen_angle_deg` | Horizontal gaze angle threshold for offscreen labeling | Default `12.0` degrees |
| `center_angle_deg` | Horizontal gaze angle threshold for center labeling | Default `7.0` degrees |
| `events` | List of sampled gaze records inside the segment | One event per sampled frame |
| `timestamp_sec` | Time in seconds from the start of the full video | No threshold |
| `segment_time_sec` | Time in seconds from the start of the current segment | No threshold |
| `gaze_detected` | Iris/gaze landmarks were available for this sample | `true` when MediaPipe FaceMesh returns usable iris landmarks |
| `offscreen_dur_sec` | Continuous duration of offscreen gaze up to this sample | Accumulates while `gaze_region = "offscreen"`; resets to `0.0` when gaze returns onscreen or gaze is not detected |
| `gaze_angle_deg` | Average horizontal gaze angle from both eyes | Used to assign `gaze_region` |
| `left_eye_angle_deg` | Horizontal gaze angle estimated from the left eye | No separate threshold |
| `right_eye_angle_deg` | Horizontal gaze angle estimated from the right eye | No separate threshold |
| `left_eye_ratio` | Normalized left iris offset inside the eye width | No separate threshold |
| `right_eye_ratio` | Normalized right iris offset inside the eye width | No separate threshold |
| `gaze_region` | Coarse gaze class | `"center"` if `abs(gaze_angle_deg) <= 7.0`; `"offscreen"` if `abs(gaze_angle_deg) > 12.0`; otherwise `"left"` or `"right"` depending on sign; `"no_gaze"` if gaze is unavailable |

These are gaze feature outputs, not final cheating decisions. MBIE later summarizes them per second using values such as `gaze_detected_ratio`, `gaze_offscreen_ratio`, and `gaze_offscreen_duration_sec`.

### 3. Posture Detector

Extracts upper-torso posture and hand-position features using MediaPipe Pose only.

```bash
py posture_detector.py --video-dir DATA_COLLECTED_VIDEOS --output-root .
```

Reads all `.mp4` files from `DATA_COLLECTED_VIDEOS/` automatically and writes MBIE-ready segment files.

**Output** — `posture_segment_XX.json` per segment:
```json
{
  "video": "EXAM-P01.mp4",
  "segment_id": "segment_01",
  "segment_start_sec": 0.0,
  "segment_end_sec": 60.0,
  "target_fps": 15.0,
  "summary": {
    "sample_count": 900,
    "pose_detected_ratio": 0.98,
    "upper_torso_visible_ratio": 0.97,
    "hand_near_mouth_ratio": 0.01,
    "upper_torso_posture_shift_ratio": 0.12,
    "elevated_hands_ratio": 0.03,
    "high_movement_ratio": 0.04,
    "mean_upper_torso_center_shift": 0.08,
    "mean_torso_movement_delta": 0.012,
    "mean_shoulder_tilt": 0.024,
    "mean_shoulder_width_ratio": 0.31
  },
  "samples": [
    {
      "segment_id": "segment_01",
      "timestamp_sec": 0.0,
      "segment_time_sec": 0.0,
      "pose_detected": true,
      "upper_torso_visible": true,
      "hand_near_mouth": false,
      "upper_torso_posture_shift": false,
      "elevated_hands": false,
      "high_movement": false,
      "arm_asymmetry_deg": 12.5,
      "shoulder_line_angle_deg": 1.35,
      "shoulder_tilt": 0.024,
      "upper_torso_center_offset_x": -0.05,
      "upper_torso_center_offset_y": -0.06,
      "upper_torso_center_shift": 0.08,
      "shoulder_width_ratio": 0.31,
      "torso_movement_delta": 0.012
    }
  ]
}
```

| Field | Meaning | Threshold / Rule |
|---|---|---|
| `summary` | Segment-level posture-only aggregation for thesis inspection and MBIE support | Computed from all samples in the segment |
| `sample_count` | Number of sampled frames in the segment | No threshold |
| `pose_detected_ratio` | Fraction of sampled frames where Pose landmarks were available | Useful quality indicator; low values mean posture features are less reliable |
| `upper_torso_visible_ratio` | Fraction of sampled frames where both shoulders were confidently visible | Shoulder visibility `>= 0.50` |
| `hand_near_mouth_ratio` | Fraction of sampled frames where `hand_near_mouth` is true | Uses wrist-to-mouth distance `< 0.20` |
| `upper_torso_posture_shift_ratio` | Fraction of sampled frames where `upper_torso_posture_shift` is true | Uses the same upper-torso shift rules listed below |
| `elevated_hands_ratio` | Fraction of sampled frames where `elevated_hands` is true | Uses wrist y-position `< shoulder y-position + 0.05` |
| `high_movement_ratio` | Fraction of sampled frames where `high_movement` is true | Uses torso-center movement `> 0.06` |
| `mean_upper_torso_center_shift` | Average shoulder-center distance from the frame center among upper-torso-visible samples | No extra threshold |
| `mean_torso_movement_delta` | Average shoulder-center movement between sampled frames among upper-torso-visible samples | No extra threshold |
| `mean_shoulder_tilt` | Average shoulder tilt among upper-torso-visible samples | No extra threshold |
| `mean_shoulder_width_ratio` | Average normalized shoulder width among upper-torso-visible samples | No extra threshold |
| `pose_detected` | MediaPipe Pose detected usable body landmarks | MediaPipe `min_detection_confidence`, default `0.5` |
| `upper_torso_visible` | Both shoulders are visible enough to compute upper-torso posture features | Shoulder visibility `>= 0.50` |
| `hand_near_mouth` | Either wrist is near the mouth center from Pose landmarks | Wrist-to-mouth distance `< 0.20` normalized frame units |
| `upper_torso_posture_shift` | Upper torso shows a notable shift from a centered seated posture | Shoulder tilt `> 0.18`, upper-torso center shift `> 0.22`, or shoulder width `< 0.22` |
| `elevated_hands` | A wrist is near or above shoulder level | Wrist y-position `< shoulder y-position + 0.05` |
| `high_movement` | Torso center moved noticeably since the previous sampled frame | Torso-center movement `> 0.06` normalized frame units |
| `arm_asymmetry_deg` | Difference between left and right shoulder-to-wrist arm angles | No direct threshold; used as a numeric feature |
| `shoulder_line_angle_deg` | Angle of the shoulder line from left shoulder to right shoulder | No direct threshold; used as a numeric feature |
| `shoulder_tilt` | Vertical difference between left and right shoulders | Used by `upper_torso_posture_shift` |
| `upper_torso_center_offset_x` | Horizontal shoulder-center position relative to frame center; `0` is centered, negative is left, positive is right | Used to compute `upper_torso_center_shift` |
| `upper_torso_center_offset_y` | Vertical shoulder-center position relative to frame center; `0` is centered, negative is up, positive is down | Used to compute `upper_torso_center_shift` |
| `upper_torso_center_shift` | Distance of the shoulder center from the frame center | Used by `upper_torso_posture_shift`; threshold `> 0.22` |
| `shoulder_width_ratio` | Normalized shoulder width in the frame | Values `< 0.22` may indicate body rotation, cropping, or side-facing posture |
| `torso_movement_delta` | Change in torso center from the previous sampled frame | Used by `high_movement` |

Posture output intentionally excludes face presence, head pose, and gaze features. Those are extracted by the face/head and gaze modules.

### Threshold and Numeric Output Interpretation

The extractor thresholds are used to create interpretable feature flags, not
final cheating decisions. A single threshold crossing is a behavioral cue only.
MBIE later aligns cues across face/head, gaze, and posture without assigning the
final label.

#### Face/Head Example

Example sample:
```json
{
  "face_center_offset_x": -0.153,
  "face_center_offset_y": -0.251,
  "face_bbox_area_ratio": 0.0622,
  "head_pose_yaw_deg": -27.46,
  "head_pose_pitch_deg": -168.75,
  "head_pose_roll_deg": -5.75,
  "head_offscreen": true
}
```

Interpretation:

| Output | What the value means | Threshold meaning |
|---|---|---|
| `face_center_offset_x = -0.153` | The face center is slightly left of the frame center. `0` means centered; negative means left; positive means right. | MBIE treats a combined face offset around `>= 0.35` as supportive evidence that the face is far from center. This example alone is not far enough horizontally. |
| `face_center_offset_y = -0.251` | The face center is above the frame center. Negative means upward; positive means downward. | Combined with `face_center_offset_x` for face-position context. |
| `face_bbox_area_ratio = 0.0622` | The detected face box occupies about `6.22%` of the frame. | MBIE treats `<= 0.04` as a small face box. This example is above `0.04`, so the face is not considered unusually small. |
| `head_pose_yaw_deg = -27.46` | The head is turned horizontally about `27.46` degrees to one side. The sign indicates direction. | `head_offscreen` becomes `true` when `abs(yaw) > 25.0`. This example crosses the threshold. |
| `head_pose_pitch_deg = -168.75` | Estimated up/down head rotation from `solvePnP`. | Stored as a numeric feature. Pitch can be camera-sensitive, so it should be interpreted with caution. |
| `head_pose_roll_deg = -5.75` | The head is tilted sideways by about `5.75` degrees. | Stored as a numeric feature; no direct flag threshold is currently applied. |
| `head_offscreen = true` | The extractor flagged a strong head turn. | This is a feature flag, not a cheating decision. |

#### Gaze Example

Example sample:
```json
{
  "gaze_detected": true,
  "offscreen_dur_sec": 0.0,
  "gaze_angle_deg": 2.51,
  "left_eye_angle_deg": 2.43,
  "right_eye_angle_deg": 2.59,
  "left_eye_ratio": 0.042,
  "right_eye_ratio": 0.045,
  "gaze_region": "center"
}
```

Interpretation:

| Output | What the value means | Threshold meaning |
|---|---|---|
| `gaze_detected = true` | Iris landmarks were available for this frame. | If gaze is not detected, the sample is marked as unavailable rather than forcing a direction. |
| `gaze_angle_deg = 2.51` | The estimated horizontal gaze angle is close to center. | `center` is assigned when `abs(gaze_angle_deg) <= 7.0`. This example is center. |
| `left_eye_angle_deg = 2.43` / `right_eye_angle_deg = 2.59` | Separate gaze estimates for each eye. | These support the averaged `gaze_angle_deg`; no separate threshold is applied. |
| `left_eye_ratio = 0.042` / `right_eye_ratio = 0.045` | Normalized iris offset inside each eye. | Used internally to estimate gaze angle. |
| `gaze_region = "center"` | Coarse gaze label for the sample. | `"offscreen"` is assigned when `abs(gaze_angle_deg) > 12.0`; values between `7.0` and `12.0` are labeled left/right instead of offscreen. |
| `offscreen_dur_sec = 0.0` | The gaze has not been continuously offscreen at this point. | This accumulates only while `gaze_region = "offscreen"` and resets when gaze returns onscreen. |

#### Posture/Upper-Torso Example

Example segment summary:
```json
{
  "pose_detected_ratio": 0.98,
  "upper_torso_visible_ratio": 0.97,
  "upper_torso_posture_shift_ratio": 0.12,
  "elevated_hands_ratio": 0.03,
  "high_movement_ratio": 0.04,
  "mean_upper_torso_center_shift": 0.08,
  "mean_torso_movement_delta": 0.012
}
```

Interpretation:

| Output | What the value means | Threshold meaning |
|---|---|---|
| `pose_detected_ratio = 0.98` | Pose landmarks were detected in `98%` of sampled frames. | This is a quality indicator. Values near `1.0` mean posture features are more reliable. |
| `upper_torso_visible_ratio = 0.97` | Both shoulders were confidently visible in `97%` of sampled frames. | This is important because the videos usually show the upper body, not the hips. |
| `upper_torso_posture_shift_ratio = 0.12` | `12%` of sampled frames showed notable upper-torso shift. | Each frame is flagged using shoulder tilt `> 0.18`, upper-torso center shift `> 0.22`, or shoulder width `< 0.22`. |
| `elevated_hands_ratio = 0.03` | Hands were near/above shoulder level in `3%` of sampled frames. | A wrist is elevated when its y-position is less than `shoulder y + 0.05`. |
| `high_movement_ratio = 0.04` | `4%` of sampled frames showed notable torso movement from the previous sampled frame. | `high_movement` is flagged when torso movement delta is `> 0.06`. |
| `mean_upper_torso_center_shift = 0.08` | Average shoulder-center distance from the frame center is `0.08` normalized frame units. | No extra threshold; it supports continuous upper-torso posture analysis. |
| `mean_torso_movement_delta = 0.012` | Average shoulder-center movement between sampled frames is `0.012` normalized frame units. | No extra threshold; higher values indicate more upper-torso movement. |

Example posture sample:
```json
{
  "upper_torso_visible": true,
  "upper_torso_center_offset_x": -0.05,
  "upper_torso_center_offset_y": -0.06,
  "upper_torso_center_shift": 0.08,
  "torso_movement_delta": 0.012,
  "shoulder_tilt": 0.024,
  "shoulder_width_ratio": 0.31,
  "upper_torso_posture_shift": false
}
```

In this sample, the shoulder center is slightly shifted but does not cross the upper-torso posture-shift threshold. The shoulder width is also above the narrow-width threshold, so the sample is treated as normal upper-torso posture evidence rather than a posture-shift flag.

### 4. MBIE Vector Fusion

Fuses face/head, gaze, and upper-torso posture cues into a time-aligned per-second
cue timeline, then creates a compact neutral JSON for the separate MLLM stage.

```bash
py -B mbie_vector_fusion.py --exam-id EXAM-P01 --input-root .
```

To process every existing `EXAM-PXX` folder from Windows Command Prompt
(`cmd.exe`), run:

```cmd
for /D %D in (EXAM-P*) do py -B mbie_vector_fusion.py --exam-id "%D" --input-root .
```

Use `%D` when typing directly into Command Prompt. Use `%%D` only if the command
is saved inside a `.bat` file. The `-B` option prevents Python from creating
`__pycache__`.

For this command, MBIE automatically reads:

- `EXAM-P01/EXAM-P01-FaceHeadOrientation_outputs/`
- `EXAM-P01/EXAM-P01_gaze_segments/`
- `EXAM-P01/EXAM-P01-posture_outputs/`

and writes to:

- `EXAM-P01/EXAM-P01_MBIE_outputs/`

Run the command once for each exam ID. By default, rerunning it replaces only
the old `mbie_segment_*.json` files and compact MLLM input for that exam. Add
`--no-clean` only when old generated MBIE files must be retained.

**Neutral cue-strength components:**

| Feature | Max Contribution |
|---|---|
| Sustained offscreen gaze | 0.20 |
| Sustained head offscreen | 0.15 |
| Sustained face absence | 0.20 |
| Simultaneous gaze and head offscreen | 0.08 |
| Off-center face with attention shift | 0.04 |
| Reduced face visibility context | 0.03 |
| Hand near mouth | 0.10 |
| Elevated hands when hand-near-mouth is not active | 0.05 |
| Upper-torso posture shift | 0.10 |
| High upper-torso movement | 0.05 |
| Mouth activity with hand near mouth | up to 0.08 |
| Multimodal corroboration | 0.10 |

Posture cues contribute only when the upper torso is sufficiently visible.
Face position and face size are supporting context and contribute only when an
attention-shift cue is also present. Cue strength is clipped to **[0.0, 1.0]**.
It is only a reproducible way to select cue-dense timestamps. It is not a
probability, confidence score, behavioral classification, or proof of cheating.

**Per-minute output** - `mbie_segment_XX.json`:

```json
{
  "schema_version": 3,
  "events": [
    {
      "timestamp_sec": 35,
      "timestamp": "MM:SS",
      "available_modalities": ["face_head", "gaze", "posture"],
      "features": { ... },
      "cue_strength": 0.45,
      "active_cues": [
        "sustained_offscreen_gaze",
        "upper_torso_posture_shift",
        "multimodal_corroboration"
      ]
    }
  ],
  "cue_strength_vector": [0.0, 0.05, 0.10, 0.45],
  "segment_summary": {
    "mean_cue_strength": 0.08,
    "p95_cue_strength": 0.32,
    "max_cue_strength": 0.45,
    "most_frequent_cues": [],
    "strong_cue_moments": [],
    "available_modalities": ["face_head", "gaze", "posture"],
    "missing_modalities": [],
    "modality_quality": {},
    "quality_warnings": []
  }
}
```

The per-minute files retain the one-second fused features for auditing,
debugging, notebook analysis, and reproducing a reported timestamp.

**Compact MLLM-ready output** -
`mbie_mllm_input_EXAM-P01.json`:

```json
{
  "mllm_input_schema_version": 2,
  "exam_id": "EXAM-P01",
  "interpretation_notice": "Cue strength is a heuristic index...",
  "cue_aggregation_configuration": { ... },
  "overall_summary": {
    "segments_analyzed": 15,
    "seconds_analyzed": 865,
    "mean_cue_strength": 0.06,
    "p95_cue_strength": 0.30,
    "max_cue_strength": 0.55,
    "cue_review_band": "notable_cue_activity",
    "most_frequent_cues": [],
    "modality_quality": {},
    "quality_warnings": []
  },
  "notable_windows": [],
  "strong_cue_moments": [],
  "recommended_visual_review_timestamps": [],
  "segment_summaries": [],
  "interpretation_constraints": []
}
```

The compact file intentionally excludes thousands of raw frame samples. It
contains the most frequent behavioral cues, data-quality warnings, notable
time windows, review timestamps, and concise minute summaries. Give this file
to the selected LLM/MLLM website. For a vision-language run, also provide only
representative frames near
`recommended_visual_review_timestamps`.

Cue-selection thresholds:

| Threshold | Current Value | Meaning |
|---|---:|---|
| Notable cue threshold | `0.20` | Consecutive seconds at or above this cue strength are merged into `notable_windows` |
| Strong cue threshold | `0.40` | Seconds at or above this cue strength are included in `strong_cue_moments` |
| Low-quality threshold | `0.50` | A modality quality score below this value produces a warning |
| Sustained-event duration | `5 seconds` | Offscreen gaze, offscreen head orientation, or face absence must persist this long for its sustained contribution |

The `cue_review_band` describes only cue density. It does not produce the final
`Suspicious behavior`, `Non-suspicious behavior`, or `Not evaluable` label.

### 5. Manual LLM/MLLM Behavioral Inference

Open the selected model website, start a new conversation, and upload:

- `EXAM-PXX/EXAM-PXX_MBIE_outputs/mbie_mllm_input_EXAM-PXX.json`
- Optional representative frames listed under
  `recommended_visual_review_timestamps`

Use the exact **ARGUS-Lite Behavioral Risk Report Prompt v1.3** archived in each
run's `prompt.txt`. Start a new conversation for every exam so one participant's
result cannot influence another. The prompt requires the model to use only the
MBIE JSON, consider data quality and benign alternatives, avoid treating
`cue_strength` as a probability, and return one of these session labels:

- `Suspicious behavior`
- `Non-suspicious behavior`
- `Not evaluable` only when most modalities are missing or unusable

The final response includes a human-readable Behavioral Risk Report and one
machine-readable JSON record containing `exam_id`, `assessment_label`,
`evidence_strength`, `reviewability`, `key_timestamps`, modality availability,
and `manual_review_recommended`. `key_timestamps` must be JSON strings in
`MM:SS` or `MM:SS-MM:SS` format. Evidence strength is ordinal wording, not a
calibrated confidence or probability.

Archive exactly four files for every model/exam run:

```text
output_generation/<model>/EXAM-PXX/
|-- ARGUS_Behavioral_Risk_Report_EXAM-PXX_<model>.pdf
|-- evaluation_record_EXAM-PXX.json
|-- prompt.txt
`-- run_metadata.txt
```

`run_metadata.txt` records the model name, prompt version, run date, MBIE input,
and input modality. The repository's archived runs use prompt v1.3; do not edit
the prompt between sessions in the same comparison experiment.

Do **not** upload `exam_labels.csv`, reveal `participant_role`, include the
known answer in the prompt, or use the labels when selecting representative
frames. Those fields are ground truth for evaluation and must remain hidden
from the model.

The evaluation maps `Suspicious behavior` to the positive ground-truth class
and `Non-suspicious behavior` to the negative class. `Not evaluable` is an
abstention and is reported through evaluation coverage. A confederate is the
participant's experimental role; the model's target is the behavioral
classification, not discovery of that hidden role.

When only JSON is supplied, describe the method as **LLM reasoning over
multimodally fused behavioral cues**. Attach representative frames when
describing the run as visual MLLM analysis.

### 6. Archived LLM Output Evaluation

After all model runs have been archived, evaluate them once per independent
participant/video session:

```bash
py -B evaluate_llm_outputs.py --input-root . --labels exam_labels.csv --expected-groups 11
```

The evaluator automatically discovers the model folders under
`output_generation/`. It validates the evaluation-record schema, timestamps,
prompt v1.3 metadata, identical prompt hashes, and the presence of exactly one
PDF report per run. It then collapses the repeated segment rows in
`exam_labels.csv` to one ground-truth label per `video_id` and generates:

- `llm_session_predictions.csv`: complete prediction and provenance table
- `llm_model_metrics.csv`: confusion counts, accuracy with 95% Wilson interval,
  balanced accuracy, precision, recall, specificity, F1, false-positive rate,
  false-negative rate, MCC, coverage, and abstentions
- `llm_pairwise_agreement.csv`: prediction agreement, Cohen's kappa, and exact
  McNemar comparison of paired correctness
- `llm_disagreements.csv` and `llm_error_analysis.csv`: session-level audit tables
- `session_prediction_comparison.csv`: truth, both LLMs, and baseline by session
- `model_metric_comparison.csv`: LLM and conventional-baseline metric table
- `llm_evaluation_summary.json` and `.txt`: machine- and human-readable summaries
- `figures/`: LLM confusion matrices, model comparison, and session prediction map

The labels and participant roles are read only after inference for evaluation;
they were not supplied to either LLM. Do not compute LLM ROC-AUC from ordinal
evidence strength, because the archived records contain no continuous,
calibrated score. Timestamp strings are format- and duration-validated, but
timestamp localization accuracy requires independent event annotations that
are not currently available.

With 11 independent sessions, report all LLM estimates as preliminary. Include
the confusion counts and class-specific metrics, especially specificity and
false-positive rate, rather than relying on accuracy alone.

### 7. Conventional Classifier Evaluation Baseline

The conventional model is deliberately separate from MBIE and the production
MLLM stage. It is used only to answer the thesis evaluation question: does MLLM
classification perform better than a simple conventional model?

After MBIE has been run for every labeled video:

```bash
py evaluate_classifier_baseline.py --input-root . --labels exam_labels.csv --expected-groups 11
```

The evaluator uses Logistic Regression and leave-one-participant/video-out
validation. Every held-out video is predicted by a model trained on other
videos only. It excludes `video_id`, `segment_id`, `participant_role`,
timestamps, MBIE `cue_strength`, and detector-quality/context fields from
model features. One-minute features are first averaged into one row per
participant/video, matching the level of the ground-truth label and preventing
pseudo-replication. Median imputation and standardization are fitted inside
each training fold.

To reduce overfitting with only 11 independent videos, the strongly regularized
model (`C=0.03`) uses five continuous, thesis-defined measurements:

- absolute head yaw
- mouth-activity ratio
- absolute gaze angle
- upper-torso center shift
- torso movement delta

These measurements represent face/head, gaze, and posture while avoiding
dependence on extractor decision thresholds such as `head_offscreen`,
`gaze_offscreen`, and `upper_torso_posture_shift`.

Outputs are written to `baseline_results/`:

- `baseline_feature_table.csv`
- `baseline_group_feature_table.csv`
- `baseline_group_predictions.csv`
- `logistic_regression_leave_one_group_out.json`

The JSON contains group-level accuracy, balanced accuracy, precision, recall,
F1, false-positive rate, ROC-AUC, confusion matrix, and held-out predictions.
These are the primary thesis results because participants/videos, not
one-minute segments, are the independent observations. The
`positive_score` is an uncalibrated baseline score and must not be described as
a true probability of cheating. No deployable model is saved because this
script is an evaluation baseline only.

By default, evaluation stops when a labeled MBIE segment is missing. Use
`--allow-missing` only for an explicitly incomplete exploratory run.

The repository currently contains labels for 11 videos. Add the actual
`EXAM-P12` rows to `exam_labels.csv` and generate its MBIE outputs before
claiming a 12-video evaluation. With only about 12 independent participants,
report this as preliminary proof-of-concept evidence, not population-level
performance. Because the current model specification was refined during
development on these 11 videos, its cross-validation metrics are development
results. Freeze the code and confirm performance on newly collected, untouched
participants before presenting a final independent-validation result.

In `exam_labels.csv`, `fps` is the source video's measured frame rate and
`duration_sec` is the duration represented by that segment. Full segments are
60 seconds; the final segment stores the remaining video duration. These
metadata fields are retained for documentation and are excluded from the
classifier features.

### 8. Analysis Notebook

`argus_feature_analysis_full.ipynb` is the documentation and visualization
companion to the baseline evaluator. It reads
`baseline_results/baseline_feature_table.csv` and
`baseline_results/logistic_regression_leave_one_group_out.json`; it does not
repeat feature extraction or train another classifier.

Run the baseline first, then open the notebook:

```bash
py evaluate_classifier_baseline.py --input-root . --labels exam_labels.csv --expected-groups 11
py -m jupyter notebook argus_feature_analysis_full.ipynb
```

Use **Restart Kernel and Run All** before exporting results. The notebook writes
publication-ready PNG figures to `thesis_figures/`:

- selected behavioral feature distributions by label
- behavioral feature correlation matrix
- exploratory PCA plot
- leave-one-group-out baseline confusion matrix

Use the feature distributions and PCA only as exploratory evidence. Use the
group-level confusion matrix and metrics for the conventional baseline
comparison with the Qwen/MLLM results.

## Full Pipeline

Run feature extraction and neutral fusion first:

```bash
py face_head_orientation_extractor_segmented.py --video-dir DATA_COLLECTED_VIDEOS --output-root .
py gaze_tracker.py --video-dir DATA_COLLECTED_VIDEOS --output-root .
py posture_detector.py --video-dir DATA_COLLECTED_VIDEOS --output-root .
py -B mbie_vector_fusion.py --exam-id EXAM-P01 --input-root .
```

The three extractors independently read the source videos. MBIE then reads
their segmented JSON outputs and creates both the fused timeline and compact
MLLM input. Upload that compact JSON to the selected model website for the
proposed-system classification. Archive the four run files, then run
`evaluate_llm_outputs.py` for the proposed-system evaluation. Run
`evaluate_classifier_baseline.py` separately only for the conventional thesis
comparison experiment.
