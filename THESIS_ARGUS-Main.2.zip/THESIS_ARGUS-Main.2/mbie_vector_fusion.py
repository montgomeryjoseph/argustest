from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from statistics import median
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple


FACE_PATTERN = "face_head_orientation_segment_*.json"
GAZE_PATTERN = "gaze_segment_*.json"
POSTURE_PATTERN = "posture_segment_*.json"

WINDOW_SECONDS = 1.0
# The thesis treats five seconds as a sustained off-screen event. The value is
# intentionally named here so it can be validated and adjusted from your labels.
SUSTAINED_EVENT_SECONDS = 5.0
# These face-position thresholds are intentionally conservative and are only
# used as supporting context when other modalities also indicate disengagement.
FACE_CENTER_OFFSET_SUPPORT_THRESH = 0.35
FACE_BBOX_SMALL_SUPPORT_THRESH = 0.04
# These thresholds select cue-dense moments for review or MLLM context. They
# are not class boundaries, probabilities, or evidence that cheating occurred.
DEFAULT_NOTABLE_CUE_THRESHOLD = 0.20
DEFAULT_STRONG_CUE_THRESHOLD = 0.40
DEFAULT_MAX_REPORT_MOMENTS = 12
LOW_QUALITY_THRESHOLD = 0.50
EXPECTED_MODALITIES = ("face_head", "gaze", "posture")

CUE_CONTRIBUTIONS = {
    "sustained_offscreen_gaze": 0.20,
    "sustained_head_offscreen": 0.15,
    "sustained_face_absence": 0.20,
    "simultaneous_gaze_and_head_offscreen": 0.08,
    "offcenter_face_with_attention_shift": 0.04,
    "reduced_face_visibility_context": 0.03,
    "hand_near_mouth": 0.10,
    "elevated_hands": 0.05,
    "upper_torso_posture_shift": 0.10,
    "high_upper_torso_movement": 0.05,
    "mouth_activity_with_hand_near_mouth": 0.08,
    "multimodal_corroboration": 0.10,
}

CUE_DESCRIPTIONS = {
    "sustained_offscreen_gaze": "Gaze remained offscreen for at least five seconds.",
    "sustained_head_offscreen": "Head orientation remained offscreen for at least five seconds.",
    "sustained_face_absence": "No face was detected for at least five seconds.",
    "simultaneous_gaze_and_head_offscreen": "Gaze and head orientation were offscreen together.",
    "offcenter_face_with_attention_shift": "The face was far from center during an attention shift.",
    "reduced_face_visibility_context": "The face appeared small during an attention shift.",
    "hand_near_mouth": "A hand was detected near the mouth region.",
    "elevated_hands": "At least one wrist was elevated near or above shoulder level.",
    "upper_torso_posture_shift": "The visible upper torso showed a notable posture shift.",
    "high_upper_torso_movement": "Upper-torso movement exceeded the extractor threshold.",
    "mouth_activity_with_hand_near_mouth": "Mouth activity and a hand-near-mouth cue occurred together.",
    "multimodal_corroboration": "Behavioral cues were supported by at least two modalities.",
}


@dataclass
class FusionState:
    """Durations carried between adjacent one-minute segment files."""

    previous_bucket: Optional[int] = None
    face_absence_duration: float = 0.0
    head_offscreen_duration: float = 0.0
    gaze_offscreen_duration: float = 0.0


def sec_to_mmss(timestamp_sec: float) -> str:
    """Convert a video timestamp in seconds to MM:SS."""
    total_seconds = max(0, int(timestamp_sec))
    return f"{total_seconds // 60:02d}:{total_seconds % 60:02d}"


def _as_float(value: Any) -> Optional[float]:
    if value is None or isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _as_bool(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes"}
    return bool(value)


def _median(values: Sequence[float]) -> Optional[float]:
    if not values:
        return None
    return round(float(median(values)), 3)


def _ratio(flags: Sequence[bool]) -> float:
    if not flags:
        return 0.0
    return round(sum(1 for flag in flags if flag) / len(flags), 3)


def _mode(values: Sequence[str]) -> Optional[str]:
    if not values:
        return None
    return Counter(values).most_common(1)[0][0]


def _mean(values: Sequence[float]) -> Optional[float]:
    if not values:
        return None
    return round(sum(values) / len(values), 3)


def _percentile(values: Sequence[float], percentile: float) -> Optional[float]:
    if not values:
        return None

    ordered = sorted(values)
    position = (len(ordered) - 1) * percentile
    lower_index = int(math.floor(position))
    upper_index = int(math.ceil(position))
    if lower_index == upper_index:
        return round(ordered[lower_index], 3)

    fraction = position - lower_index
    interpolated = (
        ordered[lower_index] * (1.0 - fraction)
        + ordered[upper_index] * fraction
    )
    return round(interpolated, 3)


def _numeric_values(samples: Sequence[Mapping[str, Any]], key: str) -> List[float]:
    values: List[float] = []
    for sample in samples:
        value = _as_float(sample.get(key))
        if value is not None:
            values.append(value)
    return values


def group_by_second(
    samples: Sequence[Mapping[str, Any]],
    time_key: str = "timestamp_sec",
) -> Dict[int, List[Mapping[str, Any]]]:
    """Collect every valid sample in its one-second video-time bucket."""
    grouped: Dict[int, List[Mapping[str, Any]]] = defaultdict(list)

    for sample in samples:
        timestamp_sec = _as_float(sample.get(time_key))
        if timestamp_sec is None or timestamp_sec < 0:
            continue
        grouped[int(math.floor(timestamp_sec))].append(sample)

    return dict(grouped)


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in {path}: {exc}") from exc


def _load_face_samples(path: Optional[Path]) -> List[Mapping[str, Any]]:
    if path is None:
        return []

    data = _load_json(path)
    if not isinstance(data, list):
        raise ValueError(f"Face/head JSON must be a list of samples: {path}")
    return [sample for sample in data if isinstance(sample, dict)]


def _load_samples_from_container(path: Optional[Path], key: str) -> List[Mapping[str, Any]]:
    if path is None:
        return []

    data = _load_json(path)
    if not isinstance(data, dict):
        raise ValueError(f"Expected an object containing '{key}' in {path}")

    samples = data.get(key, [])
    if not isinstance(samples, list):
        raise ValueError(f"'{key}' must be a list in {path}")
    return [sample for sample in samples if isinstance(sample, dict)]


def aggregate_face_samples(samples: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    """Summarize a one-second window of the updated face/head schema."""
    if not samples:
        return {}

    face_present_flags = [
        _as_bool(sample.get("face_present", False))
        for sample in samples
    ]
    visible_samples = [
        sample for sample, face_present in zip(samples, face_present_flags) if face_present
    ]
    pose_success_flags = [
        _as_bool(sample.get("pose_success", False))
        for sample in visible_samples
    ]
    pose_samples = [
        sample for sample, pose_success in zip(visible_samples, pose_success_flags) if pose_success
    ]

    yaw_values = _numeric_values(pose_samples, "head_pose_yaw_deg")
    pitch_values = _numeric_values(pose_samples, "head_pose_pitch_deg")
    roll_values = _numeric_values(pose_samples, "head_pose_roll_deg")
    center_offset_x_values = _numeric_values(visible_samples, "face_center_offset_x")
    center_offset_y_values = _numeric_values(visible_samples, "face_center_offset_y")
    bbox_area_ratio_values = _numeric_values(visible_samples, "face_bbox_area_ratio")
    head_offscreen_flags = [
        _as_bool(sample.get("head_offscreen", False))
        for sample in pose_samples
    ]
    mouth_activity_flags = [
        _as_bool(sample.get("mouth_movement", False)) for sample in visible_samples
    ]

    face_present_ratio = _ratio(face_present_flags)
    pose_success_ratio = _ratio(pose_success_flags)
    head_offscreen_ratio = _ratio(head_offscreen_flags)
    mouth_activity_ratio = _ratio(mouth_activity_flags)
    center_offset_abs_values = [
        math.hypot(x_value, y_value)
        for x_value, y_value in zip(center_offset_x_values, center_offset_y_values)
    ]
    face_center_offset_abs = _median(center_offset_abs_values)
    face_bbox_area_ratio = _median(bbox_area_ratio_values)

    return {
        "face_present": face_present_ratio >= 0.5,
        "face_present_ratio": face_present_ratio,
        "pose_success": pose_success_ratio >= 0.5,
        "pose_success_ratio": pose_success_ratio,
        "face_center_offset_x": _median(center_offset_x_values),
        "face_center_offset_y": _median(center_offset_y_values),
        "face_center_offset_abs": face_center_offset_abs,
        "face_far_from_center": (
            face_center_offset_abs is not None
            and face_center_offset_abs >= FACE_CENTER_OFFSET_SUPPORT_THRESH
        ),
        "face_bbox_area_ratio": face_bbox_area_ratio,
        "face_bbox_small": (
            face_bbox_area_ratio is not None
            and face_bbox_area_ratio <= FACE_BBOX_SMALL_SUPPORT_THRESH
        ),
        "head_yaw_deg": _median(yaw_values),
        "head_yaw_abs_deg": _median([abs(value) for value in yaw_values]),
        "head_pitch_deg": _median(pitch_values),
        "head_roll_deg": _median(roll_values),
        "head_offscreen": head_offscreen_ratio >= 0.5,
        "head_offscreen_ratio": head_offscreen_ratio,
        "mouth_activity": mouth_activity_ratio > 0.0,
        "mouth_activity_ratio": mouth_activity_ratio,
    }


def aggregate_gaze_samples(samples: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    """Summarize gaze measurements without treating a cumulative timer as a raw value."""
    if not samples:
        return {}

    gaze_detected_flags = [
        _as_bool(sample.get("gaze_detected", sample.get("gaze_angle_deg") is not None))
        for sample in samples
    ]
    detected_samples = [
        sample for sample, gaze_detected in zip(samples, gaze_detected_flags) if gaze_detected
    ]
    regions = [
        str(sample.get("gaze_region", "center")).lower() for sample in detected_samples
    ]
    offscreen_flags = []
    for sample, region in zip(detected_samples, regions):
        if "gaze_region" in sample:
            offscreen_flags.append(region == "offscreen")
        else:
            offscreen_flags.append((_as_float(sample.get("offscreen_dur_sec")) or 0.0) > 0.0)

    gaze_offscreen_ratio = _ratio(offscreen_flags)
    return {
        "gaze_detected": _ratio(gaze_detected_flags) >= 0.5,
        "gaze_detected_ratio": _ratio(gaze_detected_flags),
        "gaze_angle_deg": _median(_numeric_values(detected_samples, "gaze_angle_deg")),
        "gaze_region": _mode(regions),
        "gaze_offscreen": gaze_offscreen_ratio >= 0.5,
        "gaze_offscreen_ratio": gaze_offscreen_ratio,
        "gaze_offscreen_sec": round(gaze_offscreen_ratio * WINDOW_SECONDS, 3),
    }


def aggregate_posture_samples(samples: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    """Summarize neutral upper-torso posture features."""
    if not samples:
        return {}

    pose_detected_flags = [
        _as_bool(sample.get("pose_detected", False)) for sample in samples
    ]
    upper_torso_visible_flags = [
        _as_bool(sample.get("upper_torso_visible", False)) for sample in samples
    ]
    visible_samples = [
        sample
        for sample, visible in zip(samples, upper_torso_visible_flags)
        if visible
    ]

    pose_detected_ratio = _ratio(pose_detected_flags)
    upper_torso_visible_ratio = _ratio(upper_torso_visible_flags)
    result: Dict[str, Any] = {
        "pose_detected": pose_detected_ratio >= 0.5,
        "pose_detected_ratio": pose_detected_ratio,
        "upper_torso_visible": upper_torso_visible_ratio >= 0.5,
        "upper_torso_visible_ratio": upper_torso_visible_ratio,
    }

    for output_key in (
        "hand_near_mouth",
        "upper_torso_posture_shift",
        "elevated_hands",
        "high_movement",
    ):
        flags = [_as_bool(sample.get(output_key, False)) for sample in visible_samples]
        ratio = _ratio(flags)
        result[output_key] = ratio >= 0.5
        result[f"{output_key}_ratio"] = ratio

    for key in (
        "arm_asymmetry_deg",
        "shoulder_line_angle_deg",
        "shoulder_tilt",
        "upper_torso_center_offset_x",
        "upper_torso_center_offset_y",
        "upper_torso_center_shift",
        "shoulder_width_ratio",
        "torso_movement_delta",
    ):
        value = _median(_numeric_values(visible_samples, key))
        if value is not None:
            result[key] = value

    return result


def _next_duration(
    active: bool,
    previous_bucket: Optional[int],
    current_bucket: int,
    previous_duration: float,
) -> float:
    if not active:
        return 0.0
    if previous_bucket is not None and current_bucket == previous_bucket + 1:
        return round(previous_duration + WINDOW_SECONDS, 3)
    return WINDOW_SECONDS


def compute_cue_strength(features: Mapping[str, Any]) -> Tuple[float, List[str]]:
    """Return a neutral heuristic cue-strength index for one fused second."""
    strength = 0.0
    active_cues: List[str] = []
    evidence_modalities = set()

    gaze_duration = float(features.get("gaze_offscreen_duration_sec", 0.0) or 0.0)
    head_duration = float(features.get("head_offscreen_duration_sec", 0.0) or 0.0)
    absence_duration = float(features.get("face_absence_duration_sec", 0.0) or 0.0)

    if gaze_duration >= SUSTAINED_EVENT_SECONDS:
        strength += CUE_CONTRIBUTIONS["sustained_offscreen_gaze"]
        active_cues.append("sustained_offscreen_gaze")
        evidence_modalities.add("gaze")

    if head_duration >= SUSTAINED_EVENT_SECONDS:
        strength += CUE_CONTRIBUTIONS["sustained_head_offscreen"]
        active_cues.append("sustained_head_offscreen")
        evidence_modalities.add("face_head")

    if absence_duration >= SUSTAINED_EVENT_SECONDS:
        strength += CUE_CONTRIBUTIONS["sustained_face_absence"]
        active_cues.append("sustained_face_absence")
        evidence_modalities.add("face_head")

    if features.get("gaze_offscreen") and features.get("head_offscreen"):
        strength += CUE_CONTRIBUTIONS["simultaneous_gaze_and_head_offscreen"]
        active_cues.append("simultaneous_gaze_and_head_offscreen")
        evidence_modalities.update({"gaze", "face_head"})

    if (
        features.get("face_far_from_center")
        and (features.get("gaze_offscreen") or features.get("head_offscreen"))
    ):
        strength += CUE_CONTRIBUTIONS["offcenter_face_with_attention_shift"]
        active_cues.append("offcenter_face_with_attention_shift")
        evidence_modalities.add("face_head")

    if (
        features.get("face_bbox_small")
        and features.get("face_present")
        and (features.get("gaze_offscreen") or features.get("head_offscreen"))
    ):
        strength += CUE_CONTRIBUTIONS["reduced_face_visibility_context"]
        active_cues.append("reduced_face_visibility_context")
        evidence_modalities.add("face_head")

    posture_signal = False
    posture_is_usable = bool(features.get("upper_torso_visible"))
    if posture_is_usable and features.get("hand_near_mouth"):
        strength += CUE_CONTRIBUTIONS["hand_near_mouth"]
        active_cues.append("hand_near_mouth")
        posture_signal = True
    elif posture_is_usable and features.get("elevated_hands"):
        strength += CUE_CONTRIBUTIONS["elevated_hands"]
        active_cues.append("elevated_hands")
        posture_signal = True
    if posture_is_usable and features.get("upper_torso_posture_shift"):
        strength += CUE_CONTRIBUTIONS["upper_torso_posture_shift"]
        active_cues.append("upper_torso_posture_shift")
        posture_signal = True
    if posture_is_usable and features.get("high_movement"):
        strength += CUE_CONTRIBUTIONS["high_upper_torso_movement"]
        active_cues.append("high_upper_torso_movement")
        posture_signal = True

    if posture_signal:
        evidence_modalities.add("posture")

    mouth_activity_ratio = float(features.get("mouth_activity_ratio", 0.0) or 0.0)
    if (
        posture_is_usable
        and features.get("hand_near_mouth")
        and mouth_activity_ratio > 0.0
    ):
        max_contribution = CUE_CONTRIBUTIONS["mouth_activity_with_hand_near_mouth"]
        strength += min(max_contribution, mouth_activity_ratio * max_contribution)
        active_cues.append("mouth_activity_with_hand_near_mouth")
        evidence_modalities.add("face_head")

    if len(evidence_modalities) >= 2:
        strength += CUE_CONTRIBUTIONS["multimodal_corroboration"]
        active_cues.append("multimodal_corroboration")

    return round(max(0.0, min(1.0, strength)), 3), active_cues


def _mean_event_feature(
    events: Sequence[Mapping[str, Any]],
    modality: str,
    feature_key: str,
) -> Optional[float]:
    values: List[float] = []
    for event in events:
        if modality not in event.get("available_modalities", []):
            continue
        features = event.get("features", {})
        if not isinstance(features, Mapping):
            continue
        value = _as_float(features.get(feature_key))
        if value is not None:
            values.append(value)
    return _mean(values)


def _build_modality_quality(
    events: Sequence[Mapping[str, Any]],
) -> Dict[str, Dict[str, Any]]:
    total_seconds = len(events)
    quality: Dict[str, Dict[str, Any]] = {}

    for modality in EXPECTED_MODALITIES:
        seconds_available = sum(
            1 for event in events if modality in event.get("available_modalities", [])
        )
        coverage_ratio = (
            round(seconds_available / total_seconds, 3) if total_seconds else 0.0
        )
        entry: Dict[str, Any] = {
            "seconds_available": seconds_available,
            "coverage_ratio": coverage_ratio,
        }

        if modality == "face_head":
            face_present_ratio = _mean_event_feature(
                events,
                modality,
                "face_present_ratio",
            )
            pose_success_ratio = _mean_event_feature(
                events,
                modality,
                "pose_success_ratio",
            )
            entry["face_present_ratio"] = face_present_ratio
            entry["pose_success_ratio"] = pose_success_ratio
            quality_score = (
                round(face_present_ratio * pose_success_ratio, 3)
                if face_present_ratio is not None and pose_success_ratio is not None
                else 0.0
            )
        elif modality == "gaze":
            gaze_detected_ratio = _mean_event_feature(
                events,
                modality,
                "gaze_detected_ratio",
            )
            entry["gaze_detected_ratio"] = gaze_detected_ratio
            quality_score = gaze_detected_ratio or 0.0
        else:
            pose_detected_ratio = _mean_event_feature(
                events,
                modality,
                "pose_detected_ratio",
            )
            upper_torso_visible_ratio = _mean_event_feature(
                events,
                modality,
                "upper_torso_visible_ratio",
            )
            entry["pose_detected_ratio"] = pose_detected_ratio
            entry["upper_torso_visible_ratio"] = upper_torso_visible_ratio
            quality_score = upper_torso_visible_ratio or 0.0

        entry["quality_score"] = round(float(quality_score), 3)
        if seconds_available == 0:
            entry["status"] = "missing"
        elif quality_score < LOW_QUALITY_THRESHOLD:
            entry["status"] = "low"
        else:
            entry["status"] = "usable"
        quality[modality] = entry

    return quality


def _build_quality_warnings(
    modality_quality: Mapping[str, Mapping[str, Any]],
) -> List[Dict[str, str]]:
    warnings: List[Dict[str, str]] = []
    for modality in EXPECTED_MODALITIES:
        status = str(modality_quality.get(modality, {}).get("status", "missing"))
        if status == "missing":
            warnings.append(
                {
                    "code": f"missing_{modality}_data",
                    "message": f"No {modality} samples were available for this interval.",
                }
            )
        elif status == "low":
            warnings.append(
                {
                    "code": f"low_{modality}_quality",
                    "message": (
                        f"{modality} detection quality was below "
                        f"{LOW_QUALITY_THRESHOLD:.2f}; interpret its cues cautiously."
                    ),
                }
            )
    return warnings


def _summarize_active_cues(
    events: Sequence[Mapping[str, Any]],
    limit: int = 8,
) -> List[Dict[str, Any]]:
    counts = Counter(
        cue
        for event in events
        for cue in event.get("active_cues", [])
        if isinstance(cue, str)
    )
    return [
        {
            "cue": cue,
            "description": CUE_DESCRIPTIONS.get(cue, cue.replace("_", " ")),
            "seconds": count,
        }
        for cue, count in counts.most_common(limit)
    ]


def _summarize_moment(event: Mapping[str, Any]) -> Dict[str, Any]:
    summary: Dict[str, Any] = {
        "timestamp_sec": int(event["timestamp_sec"]),
        "timestamp": str(event["timestamp"]),
        "cue_strength": round(float(event["cue_strength"]), 3),
        "active_cues": list(event.get("active_cues", [])),
        "available_modalities": list(event.get("available_modalities", [])),
    }
    segment_id = event.get("segment_id")
    if segment_id:
        summary["segment_id"] = segment_id
    return summary


def _top_cue_moments(
    events: Sequence[Mapping[str, Any]],
    threshold: float,
    limit: int,
) -> List[Dict[str, Any]]:
    qualifying = [
        event
        for event in events
        if float(event.get("cue_strength", 0.0) or 0.0) >= threshold
    ]
    qualifying.sort(
        key=lambda event: (
            -float(event.get("cue_strength", 0.0) or 0.0),
            int(event.get("timestamp_sec", 0)),
        )
    )
    return [_summarize_moment(event) for event in qualifying[:limit]]


def _build_notable_windows(
    events: Sequence[Mapping[str, Any]],
    threshold: float,
) -> List[Dict[str, Any]]:
    qualifying = sorted(
        (
            event
            for event in events
            if float(event.get("cue_strength", 0.0) or 0.0) >= threshold
        ),
        key=lambda event: int(event.get("timestamp_sec", 0)),
    )
    if not qualifying:
        return []

    grouped: List[List[Mapping[str, Any]]] = []
    current_group: List[Mapping[str, Any]] = []
    for event in qualifying:
        timestamp_sec = int(event["timestamp_sec"])
        if (
            current_group
            and timestamp_sec != int(current_group[-1]["timestamp_sec"]) + 1
        ):
            grouped.append(current_group)
            current_group = []
        current_group.append(event)
    if current_group:
        grouped.append(current_group)

    windows: List[Dict[str, Any]] = []
    for group in grouped:
        start_sec = int(group[0]["timestamp_sec"])
        end_sec = int(group[-1]["timestamp_sec"]) + int(WINDOW_SECONDS)
        strength_values = [float(event["cue_strength"]) for event in group]
        peak_event = max(group, key=lambda event: float(event["cue_strength"]))
        segment_ids = sorted(
            {
                str(event["segment_id"])
                for event in group
                if event.get("segment_id")
            }
        )
        windows.append(
            {
                "start_sec": start_sec,
                "end_sec": end_sec,
                "start_timestamp": sec_to_mmss(start_sec),
                "end_timestamp": sec_to_mmss(end_sec),
                "duration_sec": end_sec - start_sec,
                "mean_cue_strength": _mean(strength_values),
                "peak_cue_strength": round(max(strength_values), 3),
                "peak_timestamp_sec": int(peak_event["timestamp_sec"]),
                "peak_timestamp": str(peak_event["timestamp"]),
                "dominant_cues": _summarize_active_cues(group, limit=4),
                "available_modalities": sorted(
                    {
                        modality
                        for event in group
                        for modality in event.get("available_modalities", [])
                    }
                ),
                "segment_ids": segment_ids,
            }
        )
    return windows


def _build_segment_summary(
    events: Sequence[Mapping[str, Any]],
    notable_cue_threshold: float,
    strong_cue_threshold: float,
) -> Dict[str, Any]:
    if not events:
        return {
            "seconds_analyzed": 0,
            "mean_cue_strength": 0.0,
            "p95_cue_strength": 0.0,
            "max_cue_strength": 0.0,
            "available_modalities": [],
            "missing_modalities": list(EXPECTED_MODALITIES),
            "modality_quality": {},
            "quality_warnings": [],
            "most_frequent_cues": [],
            "strong_cue_moments": [],
        }

    strength_values = [float(event["cue_strength"]) for event in events]
    feature_rows = [event["features"] for event in events]
    modality_quality = _build_modality_quality(events)
    available_modalities = [
        modality
        for modality in EXPECTED_MODALITIES
        if modality_quality[modality]["seconds_available"] > 0
    ]
    missing_modalities = [
        modality for modality in EXPECTED_MODALITIES if modality not in available_modalities
    ]

    return {
        "start_sec": int(events[0]["timestamp_sec"]),
        "end_sec": int(events[-1]["timestamp_sec"]) + int(WINDOW_SECONDS),
        "seconds_analyzed": len(events),
        "mean_cue_strength": _mean(strength_values),
        "p95_cue_strength": _percentile(strength_values, 0.95),
        "max_cue_strength": round(max(strength_values), 3),
        "notable_cue_threshold": notable_cue_threshold,
        "notable_cue_seconds": sum(
            1 for value in strength_values if value >= notable_cue_threshold
        ),
        "strong_cue_threshold": strong_cue_threshold,
        "strong_cue_seconds": sum(
            1 for value in strength_values if value >= strong_cue_threshold
        ),
        "available_modalities": available_modalities,
        "missing_modalities": missing_modalities,
        "modality_quality": modality_quality,
        "quality_warnings": _build_quality_warnings(modality_quality),
        "most_frequent_cues": _summarize_active_cues(events),
        "strong_cue_moments": _top_cue_moments(
            events,
            strong_cue_threshold,
            limit=5,
        ),
        "face_absent_seconds": sum(
            1 for features in feature_rows if features.get("face_present") is False
        ),
        "head_offscreen_seconds": sum(
            1 for features in feature_rows if features.get("head_offscreen") is True
        ),
        "face_far_from_center_seconds": sum(
            1 for features in feature_rows if features.get("face_far_from_center") is True
        ),
        "small_face_seconds": sum(
            1 for features in feature_rows if features.get("face_bbox_small") is True
        ),
        "gaze_offscreen_seconds": sum(
            1 for features in feature_rows if features.get("gaze_offscreen") is True
        ),
        "hand_near_mouth_seconds": sum(
            1 for features in feature_rows if features.get("hand_near_mouth") is True
        ),
        "upper_torso_posture_shift_seconds": sum(
            1
            for features in feature_rows
            if features.get("upper_torso_posture_shift") is True
        ),
        "elevated_hands_seconds": sum(
            1 for features in feature_rows if features.get("elevated_hands") is True
        ),
        "high_upper_torso_movement_seconds": sum(
            1 for features in feature_rows if features.get("high_movement") is True
        ),
    }


def fuse_modalities(
    face_path: Optional[Path],
    gaze_path: Optional[Path],
    posture_path: Optional[Path],
    *,
    state: Optional[FusionState] = None,
    notable_cue_threshold: float = DEFAULT_NOTABLE_CUE_THRESHOLD,
    strong_cue_threshold: float = DEFAULT_STRONG_CUE_THRESHOLD,
) -> Dict[str, Any]:
    """Fuse one face, gaze, and posture segment into time-aligned one-second events."""
    face_samples = _load_face_samples(face_path)
    gaze_samples = _load_samples_from_container(gaze_path, "events")
    posture_samples = _load_samples_from_container(posture_path, "samples")

    face_by_second = group_by_second(face_samples)
    gaze_by_second = group_by_second(gaze_samples)
    posture_by_second = group_by_second(posture_samples)
    all_buckets = sorted(set(face_by_second) | set(gaze_by_second) | set(posture_by_second))

    if not all_buckets:
        raise ValueError("The supplied segment files contain no valid timestamp_sec values.")

    fusion_state = state if state is not None else FusionState()
    fused_events: List[Dict[str, Any]] = []
    cue_strength_vector: List[float] = []

    for bucket in all_buckets:
        face_window = face_by_second.get(bucket, [])
        gaze_window = gaze_by_second.get(bucket, [])
        posture_window = posture_by_second.get(bucket, [])

        face_features = aggregate_face_samples(face_window)
        gaze_features = aggregate_gaze_samples(gaze_window)
        posture_features = aggregate_posture_samples(posture_window)

        if face_features:
            fusion_state.face_absence_duration = _next_duration(
                not face_features["face_present"],
                fusion_state.previous_bucket,
                bucket,
                fusion_state.face_absence_duration,
            )
            fusion_state.head_offscreen_duration = _next_duration(
                bool(face_features["head_offscreen"]),
                fusion_state.previous_bucket,
                bucket,
                fusion_state.head_offscreen_duration,
            )
            face_features["face_absence_duration_sec"] = (
                fusion_state.face_absence_duration
            )
            face_features["head_offscreen_duration_sec"] = (
                fusion_state.head_offscreen_duration
            )
        else:
            fusion_state.face_absence_duration = 0.0
            fusion_state.head_offscreen_duration = 0.0

        if gaze_features:
            fusion_state.gaze_offscreen_duration = _next_duration(
                bool(gaze_features["gaze_offscreen"]),
                fusion_state.previous_bucket,
                bucket,
                fusion_state.gaze_offscreen_duration,
            )
            gaze_features["gaze_offscreen_duration_sec"] = (
                fusion_state.gaze_offscreen_duration
            )
        else:
            fusion_state.gaze_offscreen_duration = 0.0

        features: Dict[str, Any] = {}
        features.update(face_features)
        features.update(gaze_features)
        features.update(posture_features)

        available_modalities = []
        if face_window:
            available_modalities.append("face_head")
        if gaze_window:
            available_modalities.append("gaze")
        if posture_window:
            available_modalities.append("posture")

        cue_strength, active_cues = compute_cue_strength(features)
        fused_events.append(
            {
                "timestamp_sec": bucket,
                "timestamp": sec_to_mmss(bucket),
                "available_modalities": available_modalities,
                "features": features,
                "cue_strength": cue_strength,
                "active_cues": active_cues,
            }
        )
        cue_strength_vector.append(cue_strength)
        fusion_state.previous_bucket = bucket

    return {
        "schema_version": 3,
        "events": fused_events,
        "cue_strength_vector": cue_strength_vector,
        "segment_summary": _build_segment_summary(
            fused_events,
            notable_cue_threshold,
            strong_cue_threshold,
        ),
    }


def _first_existing_path(candidates: Sequence[Path]) -> Path:
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return candidates[0]


def resolve_modality_dirs(
    input_root: Path,
    exam_id: str,
    face_dir: Optional[str],
    gaze_dir: Optional[str],
    posture_dir: Optional[str],
) -> Tuple[Path, Path, Path]:
    exam_root = input_root / exam_id

    resolved_face_dir = Path(face_dir) if face_dir else _first_existing_path(
        [
            exam_root / f"{exam_id}-FaceHeadOrientation_outputs",
            input_root / f"{exam_id}-FaceHeadOrientation_outputs",
        ]
    )
    resolved_gaze_dir = Path(gaze_dir) if gaze_dir else _first_existing_path(
        [
            exam_root / f"{exam_id}_gaze_segments",
            input_root / f"{exam_id}_gaze_segments",
        ]
    )
    resolved_posture_dir = Path(posture_dir) if posture_dir else _first_existing_path(
        [
            exam_root / f"{exam_id}-posture_outputs",
            input_root / f"{exam_id}-posture_outputs",
        ]
    )
    return resolved_face_dir, resolved_gaze_dir, resolved_posture_dir


def _segment_suffix(path: Path) -> Optional[str]:
    match = re.search(r"_(\d+)$", path.stem)
    if not match:
        return None
    return f"{int(match.group(1)):02d}"


def segment_file_map(folder: Path, pattern: str) -> Dict[str, Path]:
    if not folder.is_dir():
        return {}

    files: Dict[str, Path] = {}
    for path in folder.glob(pattern):
        suffix = _segment_suffix(path)
        if suffix is not None:
            files[suffix] = path
    return files


def _cue_review_band(
    p95_cue_strength: Optional[float],
    notable_cue_threshold: float,
    strong_cue_threshold: float,
    notable_seconds: int,
    strong_cue_seconds: int,
) -> str:
    if p95_cue_strength is None:
        return "insufficient_data"
    if (
        p95_cue_strength >= strong_cue_threshold
        or strong_cue_seconds >= int(SUSTAINED_EVENT_SECONDS)
    ):
        return "strong_cue_activity"
    if (
        p95_cue_strength >= notable_cue_threshold
        or notable_seconds >= int(SUSTAINED_EVENT_SECONDS)
        or strong_cue_seconds > 0
    ):
        return "notable_cue_activity"
    return "low_cue_activity"


def build_mllm_ready_input(
    exam_id: str,
    fused_segments: Sequence[Mapping[str, Any]],
    *,
    notable_cue_threshold: float,
    strong_cue_threshold: float,
    max_report_moments: int,
) -> Dict[str, Any]:
    """Create compact, neutral MLLM input without copying raw frame samples."""
    all_events: List[Dict[str, Any]] = []
    segment_summaries: List[Dict[str, Any]] = []

    for segment in fused_segments:
        segment_id = str(segment["segment_id"])
        for event in segment.get("events", []):
            if not isinstance(event, Mapping):
                continue
            event_with_segment = dict(event)
            event_with_segment["segment_id"] = segment_id
            all_events.append(event_with_segment)

        summary = segment.get("segment_summary", {})
        if isinstance(summary, Mapping):
            segment_summaries.append(
                {
                    "segment_id": segment_id,
                    **dict(summary),
                    "source_files": dict(segment.get("source_files", {})),
                }
            )

    all_events.sort(key=lambda event: int(event.get("timestamp_sec", 0)))
    strength_values = [
        float(event.get("cue_strength", 0.0) or 0.0) for event in all_events
    ]
    modality_quality = _build_modality_quality(all_events)
    available_modalities = [
        modality
        for modality in EXPECTED_MODALITIES
        if modality_quality[modality]["seconds_available"] > 0
    ]
    missing_modalities = [
        modality for modality in EXPECTED_MODALITIES if modality not in available_modalities
    ]
    p95_cue_strength = _percentile(strength_values, 0.95)
    notable_seconds = sum(
        1 for value in strength_values if value >= notable_cue_threshold
    )
    strong_cue_seconds = sum(
        1 for value in strength_values if value >= strong_cue_threshold
    )
    notable_moments = _top_cue_moments(
        all_events,
        notable_cue_threshold,
        max_report_moments,
    )

    return {
        "mllm_input_schema_version": 2,
        "exam_id": exam_id,
        "purpose": (
            "Compact, time-aligned MBIE behavioral-cue summary for a separate "
            "MLLM inference stage."
        ),
        "interpretation_notice": (
            "Cue strength is a heuristic index used only to select information-dense "
            "moments. It is not a probability, confidence score, classification, or "
            "proof that cheating occurred."
        ),
        "time_alignment": {
            "window_sec": WINDOW_SECONDS,
            "source_segmentation": "one-minute files by default",
        },
        "cue_aggregation_configuration": {
            "sustained_event_seconds": SUSTAINED_EVENT_SECONDS,
            "face_center_offset_support_threshold": FACE_CENTER_OFFSET_SUPPORT_THRESH,
            "face_bbox_small_support_threshold": FACE_BBOX_SMALL_SUPPORT_THRESH,
            "notable_cue_threshold": notable_cue_threshold,
            "strong_cue_threshold": strong_cue_threshold,
            "low_quality_threshold": LOW_QUALITY_THRESHOLD,
            "cue_contributions": CUE_CONTRIBUTIONS,
            "cue_review_band_rules": {
                "strong_cue_activity": (
                    "p95 cue strength reaches the strong-cue threshold or at least "
                    "five seconds reach the strong-cue threshold"
                ),
                "notable_cue_activity": (
                    "p95 reaches the notable threshold, at least five seconds reach "
                    "the notable threshold, or any second reaches the strong threshold"
                ),
                "low_cue_activity": "none of the strong or notable conditions are met",
            },
            "notes": [
                "Elevated hands contributes only when hand-near-mouth is not active.",
                "Face position and face size contribute only with an attention-shift cue.",
                "Posture cues contribute only when the upper torso is sufficiently visible.",
                "The per-second cue-strength index is clipped to the range 0.0 to 1.0.",
                "The cue-strength index must not be used as the final class label.",
            ],
        },
        "overall_summary": {
            "segments_analyzed": len(segment_summaries),
            "seconds_analyzed": len(all_events),
            "start_sec": (
                int(all_events[0]["timestamp_sec"]) if all_events else None
            ),
            "end_sec": (
                int(all_events[-1]["timestamp_sec"]) + int(WINDOW_SECONDS)
                if all_events
                else None
            ),
            "mean_cue_strength": _mean(strength_values) or 0.0,
            "p95_cue_strength": p95_cue_strength or 0.0,
            "max_cue_strength": (
                round(max(strength_values), 3) if strength_values else 0.0
            ),
            "cue_review_band": _cue_review_band(
                p95_cue_strength,
                notable_cue_threshold,
                strong_cue_threshold,
                notable_seconds,
                strong_cue_seconds,
            ),
            "notable_cue_seconds": notable_seconds,
            "notable_cue_seconds_ratio": (
                round(notable_seconds / len(all_events), 3) if all_events else 0.0
            ),
            "strong_cue_seconds": strong_cue_seconds,
            "strong_cue_seconds_ratio": (
                round(strong_cue_seconds / len(all_events), 3) if all_events else 0.0
            ),
            "available_modalities": available_modalities,
            "missing_modalities": missing_modalities,
            "modality_quality": modality_quality,
            "quality_warnings": _build_quality_warnings(modality_quality),
            "most_frequent_cues": _summarize_active_cues(all_events),
        },
        "notable_windows": _build_notable_windows(
            all_events,
            notable_cue_threshold,
        ),
        "strong_cue_moments": _top_cue_moments(
            all_events,
            strong_cue_threshold,
            max_report_moments,
        ),
        "recommended_visual_review_timestamps": notable_moments,
        "segment_summaries": segment_summaries,
        "interpretation_constraints": [
            "Use only the supplied behavioral cues and timestamps.",
            "Treat individual cues as ambiguous rather than proof of intent.",
            "Prioritize repeated, sustained, and multimodally corroborated observations.",
            "Account for missing or low-quality modalities.",
            "Leave classification and behavioral interpretation to the separate MLLM stage.",
        ],
    }


def clean_generated_outputs(output_dir: Path, exam_id: str) -> int:
    """Remove only MBIE files that this script regenerates."""
    old_files = list(output_dir.glob("mbie_segment_*.json"))
    for filename in (
        f"mbie_mllm_input_{exam_id}.json",
        f"mbie_report_input_{exam_id}.json",
    ):
        report_path = output_dir / filename
        if report_path.is_file():
            old_files.append(report_path)

    for path in old_files:
        path.unlink()
    return len(old_files)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Fuse face/head, gaze, and posture JSON segment files into MBIE outputs."
    )
    parser.add_argument("--exam-id", required=True, help="Exam identifier, e.g. EXAM-P01")
    parser.add_argument(
        "--input-root",
        default=".",
        help="Folder containing the EXAM-PXX output folders. Default: current folder.",
    )
    parser.add_argument("--face-dir", help="Optional explicit face/head output folder.")
    parser.add_argument("--gaze-dir", help="Optional explicit gaze output folder.")
    parser.add_argument("--posture-dir", help="Optional explicit posture output folder.")
    parser.add_argument(
        "--output-dir",
        help="Optional MBIE output folder. Defaults to EXAM-PXX/EXAM-PXX_MBIE_outputs.",
    )
    parser.add_argument(
        "--notable-cue-threshold",
        type=float,
        default=DEFAULT_NOTABLE_CUE_THRESHOLD,
        help=(
            "Minimum neutral cue strength included in notable windows. "
            f"Default: {DEFAULT_NOTABLE_CUE_THRESHOLD:.2f}."
        ),
    )
    parser.add_argument(
        "--strong-cue-threshold",
        type=float,
        default=DEFAULT_STRONG_CUE_THRESHOLD,
        help=(
            "Minimum neutral cue strength included in strong-cue moments. "
            f"Default: {DEFAULT_STRONG_CUE_THRESHOLD:.2f}."
        ),
    )
    parser.add_argument(
        "--max-report-moments",
        type=int,
        default=DEFAULT_MAX_REPORT_MOMENTS,
        help=(
            "Maximum number of timestamped moments in each compact report list. "
            f"Default: {DEFAULT_MAX_REPORT_MOMENTS}."
        ),
    )
    parser.add_argument(
        "--no-clean",
        action="store_true",
        help="Keep old MBIE segment and compact MLLM input files.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if not (
        0.0
        <= args.notable_cue_threshold
        <= args.strong_cue_threshold
        <= 1.0
    ):
        raise ValueError(
            "--notable-cue-threshold and --strong-cue-threshold must satisfy "
            "0.0 <= notable <= strong <= 1.0."
        )
    if args.max_report_moments < 1:
        raise ValueError("--max-report-moments must be at least 1.")

    input_root = Path(args.input_root)
    face_dir, gaze_dir, posture_dir = resolve_modality_dirs(
        input_root,
        args.exam_id,
        args.face_dir,
        args.gaze_dir,
        args.posture_dir,
    )
    output_dir = (
        Path(args.output_dir)
        if args.output_dir
        else input_root / args.exam_id / f"{args.exam_id}_MBIE_outputs"
    )

    for modality, folder in (
        ("face/head", face_dir),
        ("gaze", gaze_dir),
        ("posture", posture_dir),
    ):
        if not folder.is_dir():
            print(f"[warn] {modality} folder not found: {folder}")

    face_files = segment_file_map(face_dir, FACE_PATTERN)
    gaze_files = segment_file_map(gaze_dir, GAZE_PATTERN)
    posture_files = segment_file_map(posture_dir, POSTURE_PATTERN)
    segment_ids = sorted(set(face_files) | set(gaze_files) | set(posture_files), key=int)

    if not segment_ids:
        raise FileNotFoundError(
            "No segmented JSON files were found. Check --exam-id, --input-root, "
            "or the explicit modality folder arguments."
        )

    fusion_state = FusionState()
    fused_segments: List[Dict[str, Any]] = []
    for suffix in segment_ids:
        try:
            fused = fuse_modalities(
                face_files.get(suffix),
                gaze_files.get(suffix),
                posture_files.get(suffix),
                state=fusion_state,
                notable_cue_threshold=args.notable_cue_threshold,
                strong_cue_threshold=args.strong_cue_threshold,
            )
        except ValueError as exc:
            print(f"[warn] Skipped segment {suffix}: {exc}")
            continue

        fused["segment_id"] = f"segment_{suffix}"
        fused["source_files"] = {
            "face_head": face_files[suffix].name if suffix in face_files else None,
            "gaze": gaze_files[suffix].name if suffix in gaze_files else None,
            "posture": posture_files[suffix].name if suffix in posture_files else None,
        }
        fused_segments.append(fused)

    if not fused_segments:
        raise RuntimeError("No MBIE output was created from the supplied segment files.")

    compact_mllm_input = build_mllm_ready_input(
        args.exam_id,
        fused_segments,
        notable_cue_threshold=args.notable_cue_threshold,
        strong_cue_threshold=args.strong_cue_threshold,
        max_report_moments=args.max_report_moments,
    )

    output_dir.mkdir(parents=True, exist_ok=True)
    if not args.no_clean:
        removed = clean_generated_outputs(output_dir, args.exam_id)
        if removed:
            print(f"[info] Removed {removed} previous MBIE output file(s).")

    for fused in fused_segments:
        suffix = str(fused["segment_id"]).rsplit("_", 1)[-1]
        out_path = output_dir / f"mbie_segment_{suffix}.json"
        out_path.write_text(json.dumps(fused, indent=2), encoding="utf-8")

    mllm_input_path = output_dir / f"mbie_mllm_input_{args.exam_id}.json"
    mllm_input_path.write_text(
        json.dumps(compact_mllm_input, indent=2),
        encoding="utf-8",
    )

    print(
        f"[done] MBIE fusion complete: {len(fused_segments)} segment file(s) "
        f"saved in {output_dir}"
    )
    print(f"[done] Compact MLLM inference input: {mllm_input_path}")


if __name__ == "__main__":
    main()
