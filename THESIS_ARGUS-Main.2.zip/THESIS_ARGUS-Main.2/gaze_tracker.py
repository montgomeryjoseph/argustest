from __future__ import annotations

import argparse
import importlib
import json
import logging
import math
import os
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
logging.getLogger("absl").setLevel(logging.ERROR)
warnings.filterwarnings("ignore", category=UserWarning, module="google.protobuf")

DEPENDENCY_ERROR = None
FACE_MESH_CLASS = None
try:
    import cv2
    import numpy as np

    for module_name in (
        "mediapipe.python.solutions.face_mesh",
        "mediapipe.solutions.face_mesh",
    ):
        try:
            FACE_MESH_CLASS = importlib.import_module(module_name).FaceMesh
            break
        except (AttributeError, ImportError, ModuleNotFoundError):
            continue
except ModuleNotFoundError as exc:
    cv2 = None
    np = None
    FACE_MESH_CLASS = None
    DEPENDENCY_ERROR = exc


DEFAULT_VIDEO_DIR = "DATA_COLLECTED_VIDEOS"
DEFAULT_SEGMENT_LENGTH_SEC = 60.0
DEFAULT_TARGET_FPS = 15.0
DEFAULT_CENTER_ANGLE_DEG = 7.0
DEFAULT_OFFSCREEN_ANGLE_DEG = 12.0

OUTPUT_PATTERN = "gaze_segment_*.json"

LEFT_IRIS_IDS = (468, 469, 470, 471)
RIGHT_IRIS_IDS = (473, 474, 475, 476)
LEFT_EYE_CORNERS = (33, 133)
RIGHT_EYE_CORNERS = (362, 263)


def ensure_dependencies() -> None:
    if DEPENDENCY_ERROR is None and FACE_MESH_CLASS is not None:
        return

    if DEPENDENCY_ERROR is not None:
        raise RuntimeError(
            "Missing video-processing dependency. Install requirements with: "
            'py -m pip install mediapipe==0.10.14 opencv-python numpy "protobuf<5"'
        ) from DEPENDENCY_ERROR

    raise RuntimeError(
        "MediaPipe is installed, but FaceMesh could not be found in this environment. "
        "Fix it with: py -m pip uninstall -y mediapipe && "
        'py -m pip install mediapipe==0.10.14 opencv-python numpy "protobuf<5"'
    )


def segment_name(segment_index: int) -> str:
    return f"segment_{segment_index + 1:02d}"


def landmark_xy(landmarks: Sequence[Any], index: int, width: int, height: int) -> Tuple[float, float]:
    point = landmarks[index]
    return float(point.x * width), float(point.y * height)


def average_landmark_xy(
    landmarks: Sequence[Any],
    indices: Sequence[int],
    width: int,
    height: int,
) -> Tuple[float, float]:
    points = [landmark_xy(landmarks, index, width, height) for index in indices]
    return float(np.mean([point[0] for point in points])), float(np.mean([point[1] for point in points]))


def eye_width_px(
    landmarks: Sequence[Any],
    corners: Tuple[int, int],
    width: int,
    height: int,
) -> float:
    left = landmark_xy(landmarks, corners[0], width, height)
    right = landmark_xy(landmarks, corners[1], width, height)
    return max(10.0, math.hypot(left[0] - right[0], left[1] - right[1]))


def eye_center_xy(
    landmarks: Sequence[Any],
    corners: Tuple[int, int],
    width: int,
    height: int,
) -> Tuple[float, float]:
    left = landmark_xy(landmarks, corners[0], width, height)
    right = landmark_xy(landmarks, corners[1], width, height)
    return (left[0] + right[0]) / 2.0, (left[1] + right[1]) / 2.0


def eye_ratio_and_angle(
    eye_center: Tuple[float, float],
    iris_center: Tuple[float, float],
    eye_width: float,
) -> Tuple[float, float]:
    dx = iris_center[0] - eye_center[0]
    ratio = dx / eye_width
    angle_deg = math.degrees(math.atan(ratio))
    return float(ratio), float(angle_deg)


def compute_gaze_features(
    landmarks: Sequence[Any],
    image_shape: Tuple[int, int, int],
    center_angle_deg: float,
    offscreen_angle_deg: float,
) -> Optional[Dict[str, Any]]:
    """Estimate horizontal gaze from iris position inside each eye."""
    height, width = image_shape[:2]

    if len(landmarks) <= max(*LEFT_IRIS_IDS, *RIGHT_IRIS_IDS):
        return None

    left_iris = average_landmark_xy(landmarks, LEFT_IRIS_IDS, width, height)
    right_iris = average_landmark_xy(landmarks, RIGHT_IRIS_IDS, width, height)
    left_eye_center = eye_center_xy(landmarks, LEFT_EYE_CORNERS, width, height)
    right_eye_center = eye_center_xy(landmarks, RIGHT_EYE_CORNERS, width, height)
    left_eye_width = eye_width_px(landmarks, LEFT_EYE_CORNERS, width, height)
    right_eye_width = eye_width_px(landmarks, RIGHT_EYE_CORNERS, width, height)

    left_ratio, left_angle = eye_ratio_and_angle(left_eye_center, left_iris, left_eye_width)
    right_ratio, right_angle = eye_ratio_and_angle(right_eye_center, right_iris, right_eye_width)
    gaze_angle = (left_angle + right_angle) / 2.0

    if abs(gaze_angle) > offscreen_angle_deg:
        gaze_region = "offscreen"
    elif abs(gaze_angle) <= center_angle_deg:
        gaze_region = "center"
    elif gaze_angle < 0:
        gaze_region = "left"
    else:
        gaze_region = "right"

    return {
        "gaze_angle_deg": gaze_angle,
        "left_eye_angle_deg": left_angle,
        "right_eye_angle_deg": right_angle,
        "left_eye_ratio": left_ratio,
        "right_eye_ratio": right_ratio,
        "gaze_region": gaze_region,
        "gaze_offscreen": gaze_region == "offscreen",
    }


def clean_previous_outputs(out_dir: Path) -> int:
    removed = 0
    for old_file in out_dir.glob(OUTPUT_PATTERN):
        old_file.unlink()
        removed += 1
    return removed


def write_segment(
    out_dir: Path,
    video_path: Path,
    segment_index: int,
    segment_start_sec: float,
    segment_end_sec: float,
    target_fps: float,
    offscreen_angle_deg: float,
    center_angle_deg: float,
    events: List[Dict[str, Any]],
) -> Path:
    segment_id = segment_name(segment_index)
    out_path = out_dir / f"gaze_segment_{segment_index + 1:02d}.json"
    payload = {
        "video": video_path.name,
        "segment_id": segment_id,
        "segment_start_sec": round(segment_start_sec, 3),
        "segment_end_sec": round(segment_end_sec, 3),
        "target_fps": target_fps,
        "offscreen_angle_deg": offscreen_angle_deg,
        "center_angle_deg": center_angle_deg,
        "events": events,
    }
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"[saved] {out_path} ({len(events)} events)")
    return out_path


def process_video(
    video_path: Path,
    out_dir: Path,
    *,
    segment_length_sec: float = DEFAULT_SEGMENT_LENGTH_SEC,
    target_fps: float = DEFAULT_TARGET_FPS,
    sample_every: Optional[int] = None,
    offscreen_angle_deg: float = DEFAULT_OFFSCREEN_ANGLE_DEG,
    center_angle_deg: float = DEFAULT_CENTER_ANGLE_DEG,
    min_detection_confidence: float = 0.5,
    min_tracking_confidence: float = 0.5,
    clean_output: bool = True,
) -> List[Path]:
    ensure_dependencies()

    video_path = Path(video_path)
    out_dir = Path(out_dir)

    if not video_path.exists():
        raise FileNotFoundError(f"Video not found: {video_path}")
    if segment_length_sec <= 0:
        raise ValueError("segment_length_sec must be greater than zero")
    if target_fps <= 0:
        raise ValueError("target_fps must be greater than zero")
    if sample_every is not None and sample_every < 1:
        raise ValueError("sample_every must be 1 or greater")
    if center_angle_deg < 0 or offscreen_angle_deg <= center_angle_deg:
        raise ValueError("offscreen_angle_deg must be greater than center_angle_deg")

    out_dir.mkdir(parents=True, exist_ok=True)
    if clean_output:
        removed = clean_previous_outputs(out_dir)
        if removed:
            print(f"[clean] Removed {removed} old gaze segment file(s) from {out_dir}")

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Could not open video: {video_path}")

    video_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frame_stride = sample_every or max(1, round(video_fps / target_fps))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    duration_sec = total_frames / video_fps if video_fps > 0 else 0.0

    print(f"[info] Video: {video_path}")
    print(f"[info] Output: {out_dir}")
    print(f"[info] Duration: {duration_sec / 60.0:.2f} min, FPS: {video_fps:.2f}")
    print(f"[info] Segment length: {segment_length_sec:.0f}s, frame stride: {frame_stride}")

    current_segment_index: Optional[int] = None
    current_events: List[Dict[str, Any]] = []
    written_files: List[Path] = []
    frame_idx = 0
    processed_frames = 0
    gaze_detected_frames = 0
    offscreen_duration_sec = 0.0
    previous_sample_time: Optional[float] = None

    try:
        with FACE_MESH_CLASS(
            static_image_mode=False,
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        ) as face_mesh:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                frame_idx += 1
                if frame_idx % frame_stride != 0:
                    continue

                processed_frames += 1
                timestamp_sec = (frame_idx - 1) / video_fps
                sample_interval_sec = (
                    timestamp_sec - previous_sample_time
                    if previous_sample_time is not None
                    else frame_stride / video_fps
                )
                previous_sample_time = timestamp_sec

                segment_index = int(timestamp_sec // segment_length_sec)
                segment_start_time = segment_index * segment_length_sec
                segment_time_sec = timestamp_sec - segment_start_time

                if current_segment_index is None:
                    current_segment_index = segment_index
                elif segment_index != current_segment_index:
                    written_files.append(
                        write_segment(
                            out_dir,
                            video_path,
                            current_segment_index,
                            current_segment_index * segment_length_sec,
                            timestamp_sec,
                            target_fps,
                            offscreen_angle_deg,
                            center_angle_deg,
                            current_events,
                        )
                    )
                    current_events = []
                    current_segment_index = segment_index

                event: Dict[str, Any] = {
                    "segment_id": segment_name(segment_index),
                    "timestamp_sec": round(timestamp_sec, 3),
                    "segment_time_sec": round(segment_time_sec, 3),
                    "gaze_detected": False,
                    "offscreen_dur_sec": None,
                    "gaze_angle_deg": None,
                    "left_eye_angle_deg": None,
                    "right_eye_angle_deg": None,
                    "left_eye_ratio": None,
                    "right_eye_ratio": None,
                    "gaze_region": "no_gaze",
                }

                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = face_mesh.process(frame_rgb)
                if not results.multi_face_landmarks:
                    offscreen_duration_sec = 0.0
                    current_events.append(event)
                    continue

                landmarks = results.multi_face_landmarks[0].landmark
                features = compute_gaze_features(
                    landmarks,
                    frame.shape,
                    center_angle_deg,
                    offscreen_angle_deg,
                )
                if features is None:
                    offscreen_duration_sec = 0.0
                    current_events.append(event)
                    continue

                gaze_detected_frames += 1
                if features["gaze_offscreen"]:
                    offscreen_duration_sec = round(offscreen_duration_sec + sample_interval_sec, 3)
                else:
                    offscreen_duration_sec = 0.0

                event.update(
                    {
                        "gaze_detected": True,
                        "offscreen_dur_sec": round(offscreen_duration_sec, 3),
                        "gaze_angle_deg": round(float(features["gaze_angle_deg"]), 2),
                        "left_eye_angle_deg": round(float(features["left_eye_angle_deg"]), 2),
                        "right_eye_angle_deg": round(float(features["right_eye_angle_deg"]), 2),
                        "left_eye_ratio": round(float(features["left_eye_ratio"]), 3),
                        "right_eye_ratio": round(float(features["right_eye_ratio"]), 3),
                        "gaze_region": features["gaze_region"],
                    }
                )
                current_events.append(event)
    finally:
        cap.release()

    if current_segment_index is not None and current_events:
        written_files.append(
            write_segment(
                out_dir,
                video_path,
                current_segment_index,
                current_segment_index * segment_length_sec,
                duration_sec,
                target_fps,
                offscreen_angle_deg,
                center_angle_deg,
                current_events,
            )
        )

    detection_rate = gaze_detected_frames / processed_frames if processed_frames else 0.0
    print(
        f"[done] {video_path.name}: {len(written_files)} segment file(s), "
        f"{processed_frames} sampled frame(s), gaze detected in {detection_rate:.1%}"
    )
    return written_files


def find_video_files(video: Optional[str], video_dir: Optional[str], exam_id: Optional[str]) -> List[Path]:
    if video:
        return [Path(video)]

    search_dir = Path(video_dir or DEFAULT_VIDEO_DIR)
    if not search_dir.exists():
        raise FileNotFoundError(
            f"Video directory not found: {search_dir}. "
            "Pass --video or point --video-dir to your external DATA_COLLECTED_VIDEOS folder."
        )

    videos = sorted(search_dir.glob("*.mp4"))
    if exam_id:
        target_name = f"{exam_id}.mp4"
        videos = [path for path in videos if path.name.lower() == target_name.lower()]

    if not videos:
        label = f" matching {exam_id}" if exam_id else ""
        raise FileNotFoundError(f"No MP4 video files{label} found in {search_dir}")

    return videos


def default_output_dir(video_path: Path, output_root: Path) -> Path:
    video_stem = video_path.stem
    return output_root / video_stem / f"{video_stem}_gaze_segments"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Extract eye-gaze features into standalone segmented JSON artifacts. "
            "Default output is EXAM-PXX/EXAM-PXX_gaze_segments/."
        )
    )
    parser.add_argument("--video", help="Path to one MP4 file, e.g. DATA_COLLECTED_VIDEOS/EXAM-P01.mp4")
    parser.add_argument(
        "--video-dir",
        default=None,
        help=f"Folder containing MP4 files. Defaults to {DEFAULT_VIDEO_DIR} when --video is omitted.",
    )
    parser.add_argument("--exam-id", help="Optional exam ID filter, e.g. EXAM-P01")
    parser.add_argument(
        "--out",
        default=None,
        help="Output folder for single-video runs. For batch runs, use --output-root instead.",
    )
    parser.add_argument(
        "--output-root",
        default=".",
        help="Root where EXAM-PXX/EXAM-PXX_gaze_segments folders will be created.",
    )
    parser.add_argument("--segment-length-sec", type=float, default=DEFAULT_SEGMENT_LENGTH_SEC)
    parser.add_argument("--target-fps", type=float, default=DEFAULT_TARGET_FPS)
    parser.add_argument(
        "--sample-every",
        type=int,
        default=None,
        help="Process every Nth frame. Overrides --target-fps when supplied.",
    )
    parser.add_argument("--center-angle-deg", type=float, default=DEFAULT_CENTER_ANGLE_DEG)
    parser.add_argument("--offscreen-angle-deg", type=float, default=DEFAULT_OFFSCREEN_ANGLE_DEG)
    parser.add_argument("--min-detection-confidence", type=float, default=0.5)
    parser.add_argument("--min-tracking-confidence", type=float, default=0.5)
    parser.add_argument("--no-clean", action="store_true", help="Keep old gaze_segment_*.json files.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    videos = find_video_files(args.video, args.video_dir, args.exam_id)
    output_root = Path(args.output_root)

    if args.out and len(videos) > 1:
        raise ValueError("--out can only be used with one video. Use --output-root for batch runs.")

    for video_path in videos:
        out_dir = Path(args.out) if args.out else default_output_dir(video_path, output_root)
        process_video(
            video_path,
            out_dir,
            segment_length_sec=args.segment_length_sec,
            target_fps=args.target_fps,
            sample_every=args.sample_every,
            offscreen_angle_deg=args.offscreen_angle_deg,
            center_angle_deg=args.center_angle_deg,
            min_detection_confidence=args.min_detection_confidence,
            min_tracking_confidence=args.min_tracking_confidence,
            clean_output=not args.no_clean,
        )


if __name__ == "__main__":
    main()
