"""Evaluate archived ARGUS-Lite LLM decisions at the video-session level."""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import platform
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple


POSITIVE_LABEL = "Suspicious behavior"
NEGATIVE_LABEL = "Non-suspicious behavior"
ABSTENTION_LABEL = "Not evaluable"
PROMPT_VERSION_RE = re.compile(r"\b(?:version\s+|v)(\d+(?:\.\d+)*)\b", re.IGNORECASE)
TIMESTAMP_RE = re.compile(r"^(\d+):(\d{2})(?:-(\d+):(\d{2}))?$")


@dataclass(frozen=True)
class GroundTruth:
    exam_id: str
    binary_label: int
    display_label: str
    source_label: str
    participant_role: str
    segment_count: int
    duration_sec: float
    source_fps: str


@dataclass(frozen=True)
class PredictionRecord:
    model: str
    exam_id: str
    predicted_binary: Optional[int]
    assessment_label: str
    evidence_strength: str
    reviewability: str
    key_timestamps: Tuple[str, ...]
    available_modalities: Tuple[str, ...]
    missing_modalities: Tuple[str, ...]
    manual_review_recommended: bool
    prompt_version_metadata: str
    prompt_version_file: str
    prompt_sha256: str
    evaluation_record_path: str
    report_path: str


def _normalize_token(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def _normalize_truth_label(value: Any) -> int:
    token = _normalize_token(value)
    if token in {"cheating", "suspicious", "suspicious_behavior", "positive", "1"}:
        return 1
    if token in {
        "non_cheating",
        "non_suspicious",
        "non_suspicious_behavior",
        "negative",
        "0",
    }:
        return 0
    raise ValueError(f"Unsupported ground-truth label: {value!r}")


def _normalize_prediction_label(value: Any) -> Optional[int]:
    token = _normalize_token(value)
    if token in {"suspicious", "suspicious_behavior"}:
        return 1
    if token in {"non_suspicious", "non_suspicious_behavior"}:
        return 0
    if token in {"not_evaluable", "insufficient_evidence", "abstain", "abstention"}:
        return None
    raise ValueError(f"Unsupported LLM assessment label: {value!r}")


def _display_label(binary_label: int) -> str:
    return POSITIVE_LABEL if binary_label == 1 else NEGATIVE_LABEL


def _exam_sort_key(exam_id: str) -> Tuple[float, str]:
    match = re.search(r"(\d+)$", exam_id)
    return (int(match.group(1)) if match else math.inf, exam_id)


def _model_sort_key(model: str) -> Tuple[int, str]:
    lowered = model.lower()
    if lowered.startswith("qwen"):
        return (0, model)
    if lowered.startswith("openai"):
        return (1, model)
    return (2, model)


def _safe_float(value: Any, *, field_name: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid numeric value for {field_name}: {value!r}") from exc
    if not math.isfinite(number):
        raise ValueError(f"Non-finite numeric value for {field_name}: {value!r}")
    return number


def _safe_divide(numerator: float, denominator: float) -> Optional[float]:
    return numerator / denominator if denominator else None


def _rounded(value: Optional[float], digits: int = 4) -> Optional[float]:
    return round(value, digits) if value is not None else None


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _extract_prompt_version(text: str) -> str:
    match = PROMPT_VERSION_RE.search(text)
    return match.group(1) if match else ""


def _metadata_value(path: Path, key: str) -> str:
    if not path.is_file():
        return ""
    prefix = f"{key}:"
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        if line.startswith(prefix):
            return line[len(prefix) :].strip()
    return ""


def _timestamp_to_seconds(value: str) -> Tuple[int, int]:
    match = TIMESTAMP_RE.fullmatch(value)
    if not match:
        raise ValueError(
            f"Invalid key timestamp {value!r}; expected MM:SS or MM:SS-MM:SS."
        )
    start_minute, start_second = int(match.group(1)), int(match.group(2))
    if start_second >= 60:
        raise ValueError(f"Invalid seconds component in key timestamp {value!r}.")
    start = start_minute * 60 + start_second
    if match.group(3) is None:
        return start, start
    end_minute, end_second = int(match.group(3)), int(match.group(4))
    if end_second >= 60:
        raise ValueError(f"Invalid seconds component in key timestamp {value!r}.")
    end = end_minute * 60 + end_second
    if end < start:
        raise ValueError(f"Timestamp window ends before it begins: {value!r}.")
    return start, end


def load_ground_truth(path: Path) -> Tuple[Dict[str, GroundTruth], int]:
    if not path.is_file():
        raise FileNotFoundError(f"Ground-truth CSV not found: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    required = {"video_id", "label"}
    if not rows or not required.issubset(rows[0]):
        raise ValueError(
            f"{path} must contain at least these columns: {sorted(required)}"
        )

    grouped: Dict[str, List[Mapping[str, str]]] = {}
    for row in rows:
        exam_id = str(row.get("video_id", "")).strip()
        if not exam_id:
            raise ValueError("Every label row must contain a non-empty video_id.")
        grouped.setdefault(exam_id, []).append(row)

    truth: Dict[str, GroundTruth] = {}
    for exam_id, exam_rows in grouped.items():
        labels = {_normalize_truth_label(row.get("label")) for row in exam_rows}
        if len(labels) != 1:
            raise ValueError(f"Conflicting labels were found for {exam_id}.")
        roles = {
            str(row.get("participant_role", "")).strip()
            for row in exam_rows
            if str(row.get("participant_role", "")).strip()
        }
        if len(roles) > 1:
            raise ValueError(f"Conflicting participant roles were found for {exam_id}.")
        source_labels = {
            str(row.get("label", "")).strip()
            for row in exam_rows
            if str(row.get("label", "")).strip()
        }
        durations = [
            _safe_float(row.get("duration_sec", 0), field_name="duration_sec")
            for row in exam_rows
        ]
        fps_values = sorted(
            {
                str(row.get("fps", "")).strip()
                for row in exam_rows
                if str(row.get("fps", "")).strip()
            }
        )
        binary_label = next(iter(labels))
        truth[exam_id] = GroundTruth(
            exam_id=exam_id,
            binary_label=binary_label,
            display_label=_display_label(binary_label),
            source_label="|".join(sorted(source_labels)),
            participant_role="|".join(sorted(roles)),
            segment_count=len(exam_rows),
            duration_sec=sum(durations),
            source_fps="|".join(fps_values),
        )
    return truth, len(rows)


def discover_model_directories(
    output_root: Path,
    requested_models: Sequence[str],
) -> List[Tuple[str, Path]]:
    if not output_root.is_dir():
        raise FileNotFoundError(f"LLM output directory not found: {output_root}")
    candidates: List[Tuple[str, Path]] = []
    for child in output_root.iterdir():
        if not child.is_dir():
            continue
        if any(child.glob("EXAM-P*/evaluation_record_EXAM-P*.json")):
            candidates.append((child.name, child))
    if requested_models:
        requested = set(requested_models)
        candidates = [item for item in candidates if item[0] in requested]
        missing = requested.difference(model for model, _ in candidates)
        if missing:
            raise FileNotFoundError(
                f"No evaluation records were found for model directories: "
                f"{sorted(missing)}"
            )
    if len(candidates) < 2:
        raise ValueError("At least two LLM result directories are required.")
    return sorted(candidates, key=lambda item: _model_sort_key(item[0]))


def load_model_predictions(
    model: str,
    model_dir: Path,
    truth: Mapping[str, GroundTruth],
    expected_prompt_version: str,
    allow_prompt_version_mismatch: bool,
) -> Tuple[Dict[str, PredictionRecord], List[str]]:
    records: Dict[str, PredictionRecord] = {}
    warnings: List[str] = []
    record_paths = sorted(
        model_dir.glob("EXAM-P*/evaluation_record_EXAM-P*.json"),
        key=lambda path: _exam_sort_key(path.parent.name),
    )
    for record_path in record_paths:
        data = json.loads(record_path.read_text(encoding="utf-8-sig"))
        if not isinstance(data, Mapping):
            raise ValueError(f"Evaluation record must be a JSON object: {record_path}")
        exam_id = str(data.get("exam_id", "")).strip()
        if not exam_id:
            raise ValueError(f"Missing exam_id in {record_path}")
        if exam_id in records:
            raise ValueError(f"Duplicate {model} evaluation record for {exam_id}.")
        if exam_id not in truth:
            raise ValueError(f"{model} contains an unlabeled exam: {exam_id}.")
        if record_path.parent.name != exam_id:
            raise ValueError(
                f"Evaluation record exam_id {exam_id!r} does not match folder "
                f"{record_path.parent.name!r}."
            )

        assessment_label = str(data.get("assessment_label", "")).strip()
        predicted_binary = _normalize_prediction_label(assessment_label)
        evidence_strength = str(data.get("evidence_strength", "")).strip()
        if evidence_strength.lower() not in {"low", "moderate", "high"}:
            raise ValueError(
                f"Invalid evidence_strength for {model} {exam_id}: "
                f"{evidence_strength!r}"
            )
        reviewability = str(data.get("reviewability", "")).strip()
        if reviewability.lower() not in {"adequate", "limited", "not evaluable"}:
            raise ValueError(
                f"Invalid reviewability for {model} {exam_id}: {reviewability!r}"
            )
        key_timestamps_raw = data.get("key_timestamps", [])
        if not isinstance(key_timestamps_raw, list):
            raise ValueError(f"key_timestamps must be an array in {record_path}")
        key_timestamps: List[str] = []
        for value in key_timestamps_raw:
            if not isinstance(value, str):
                raise ValueError(
                    f"Every key timestamp must be a JSON string in {record_path}"
                )
            _, end = _timestamp_to_seconds(value)
            if end > truth[exam_id].duration_sec + 1:
                raise ValueError(
                    f"Timestamp {value!r} exceeds the labeled duration for {exam_id}."
                )
            key_timestamps.append(value)

        available = data.get("available_modalities", [])
        missing = data.get("missing_modalities", [])
        if not isinstance(available, list) or not all(
            isinstance(value, str) for value in available
        ):
            raise ValueError(f"available_modalities must be a string array: {record_path}")
        if not isinstance(missing, list) or not all(
            isinstance(value, str) for value in missing
        ):
            raise ValueError(f"missing_modalities must be a string array: {record_path}")
        manual_review = data.get("manual_review_recommended")
        if not isinstance(manual_review, bool):
            raise ValueError(
                f"manual_review_recommended must be boolean in {record_path}"
            )

        prompt_path = record_path.parent / "prompt.txt"
        metadata_path = record_path.parent / "run_metadata.txt"
        if not prompt_path.is_file() or not metadata_path.is_file():
            raise FileNotFoundError(
                f"Missing prompt.txt or run_metadata.txt beside {record_path}"
            )
        prompt_text = prompt_path.read_text(encoding="utf-8-sig")
        prompt_version_file = _extract_prompt_version(prompt_text.splitlines()[0])
        prompt_version_metadata = _extract_prompt_version(
            _metadata_value(metadata_path, "Prompt version")
        )
        versions_match = (
            prompt_version_file == expected_prompt_version
            and prompt_version_metadata == expected_prompt_version
        )
        if not versions_match:
            message = (
                f"{model} {exam_id} prompt versions do not match expected "
                f"v{expected_prompt_version}: file={prompt_version_file!r}, "
                f"metadata={prompt_version_metadata!r}."
            )
            if allow_prompt_version_mismatch:
                warnings.append(message)
            else:
                raise ValueError(message)

        reports = sorted(record_path.parent.glob("*.pdf"))
        if len(reports) != 1:
            raise ValueError(
                f"Expected exactly one PDF report beside {record_path}; found {len(reports)}."
            )
        records[exam_id] = PredictionRecord(
            model=model,
            exam_id=exam_id,
            predicted_binary=predicted_binary,
            assessment_label=assessment_label,
            evidence_strength=evidence_strength,
            reviewability=reviewability,
            key_timestamps=tuple(key_timestamps),
            available_modalities=tuple(available),
            missing_modalities=tuple(missing),
            manual_review_recommended=manual_review,
            prompt_version_metadata=prompt_version_metadata,
            prompt_version_file=prompt_version_file,
            prompt_sha256=_sha256(prompt_path),
            evaluation_record_path=str(record_path.resolve()),
            report_path=str(reports[0].resolve()),
        )
    return records, warnings


def _wilson_interval(successes: int, total: int, z: float = 1.96) -> Tuple[Optional[float], Optional[float]]:
    if total <= 0:
        return None, None
    proportion = successes / total
    denominator = 1 + (z * z / total)
    center = (proportion + z * z / (2 * total)) / denominator
    margin = (
        z
        * math.sqrt(
            proportion * (1 - proportion) / total
            + z * z / (4 * total * total)
        )
        / denominator
    )
    return max(0.0, center - margin), min(1.0, center + margin)


def calculate_binary_metrics(
    truth_values: Sequence[int],
    prediction_values: Sequence[int],
) -> Dict[str, Any]:
    if len(truth_values) != len(prediction_values):
        raise ValueError("Truth and prediction arrays must have equal length.")
    tn = fp = fn = tp = 0
    for truth, prediction in zip(truth_values, prediction_values):
        if truth == 0 and prediction == 0:
            tn += 1
        elif truth == 0 and prediction == 1:
            fp += 1
        elif truth == 1 and prediction == 0:
            fn += 1
        elif truth == 1 and prediction == 1:
            tp += 1
        else:
            raise ValueError("Metrics require binary values 0 and 1.")
    total = len(truth_values)
    accuracy = _safe_divide(tp + tn, total)
    precision = _safe_divide(tp, tp + fp)
    recall = _safe_divide(tp, tp + fn)
    specificity = _safe_divide(tn, tn + fp)
    f1 = _safe_divide(2 * tp, 2 * tp + fp + fn)
    balanced_accuracy = (
        (recall + specificity) / 2
        if recall is not None and specificity is not None
        else None
    )
    false_positive_rate = _safe_divide(fp, fp + tn)
    false_negative_rate = _safe_divide(fn, fn + tp)
    denominator = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    matthews_correlation = (tp * tn - fp * fn) / denominator if denominator else None
    ci_low, ci_high = _wilson_interval(tp + tn, total)
    return {
        "evaluated_sessions": total,
        "true_negative": tn,
        "false_positive": fp,
        "false_negative": fn,
        "true_positive": tp,
        "confusion_matrix": [[tn, fp], [fn, tp]],
        "accuracy": _rounded(accuracy),
        "accuracy_ci95_wilson_low": _rounded(ci_low),
        "accuracy_ci95_wilson_high": _rounded(ci_high),
        "balanced_accuracy": _rounded(balanced_accuracy),
        "precision": _rounded(precision),
        "recall_sensitivity": _rounded(recall),
        "specificity": _rounded(specificity),
        "f1": _rounded(f1),
        "false_positive_rate": _rounded(false_positive_rate),
        "false_negative_rate": _rounded(false_negative_rate),
        "matthews_correlation": _rounded(matthews_correlation),
    }


def evaluate_model(
    model: str,
    records: Mapping[str, PredictionRecord],
    truth: Mapping[str, GroundTruth],
    allow_missing: bool,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
    missing = sorted(set(truth).difference(records), key=_exam_sort_key)
    if missing and not allow_missing:
        raise ValueError(f"{model} is missing evaluation records for: {missing}")
    rows: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    truth_values: List[int] = []
    prediction_values: List[int] = []
    abstentions = 0
    for exam_id in sorted(truth, key=_exam_sort_key):
        target = truth[exam_id]
        prediction = records.get(exam_id)
        if prediction is None:
            rows.append(
                {
                    "model": model,
                    "exam_id": exam_id,
                    "true_label": target.display_label,
                    "true_binary": target.binary_label,
                    "participant_role_evaluation_only": target.participant_role,
                    "segments": target.segment_count,
                    "duration_sec": _rounded(target.duration_sec, 3),
                    "source_fps": target.source_fps,
                    "predicted_label": "Missing record",
                    "predicted_binary": "",
                    "evaluation_status": "missing",
                    "correct": "",
                }
            )
            continue
        if prediction.predicted_binary is None:
            abstentions += 1
            status = "abstained"
            correct: Any = ""
        else:
            truth_values.append(target.binary_label)
            prediction_values.append(prediction.predicted_binary)
            is_correct = target.binary_label == prediction.predicted_binary
            status = "correct" if is_correct else "incorrect"
            correct = is_correct
        row = {
            "model": model,
            "exam_id": exam_id,
            "true_label": target.display_label,
            "true_binary": target.binary_label,
            "participant_role_evaluation_only": target.participant_role,
            "segments": target.segment_count,
            "duration_sec": _rounded(target.duration_sec, 3),
            "source_fps": target.source_fps,
            "predicted_label": prediction.assessment_label,
            "predicted_binary": (
                prediction.predicted_binary
                if prediction.predicted_binary is not None
                else ""
            ),
            "evaluation_status": status,
            "correct": correct,
            "evidence_strength": prediction.evidence_strength,
            "reviewability": prediction.reviewability,
            "manual_review_recommended": prediction.manual_review_recommended,
            "key_timestamp_count": len(prediction.key_timestamps),
            "key_timestamps": "; ".join(prediction.key_timestamps),
            "available_modalities": "; ".join(prediction.available_modalities),
            "missing_modalities": "; ".join(prediction.missing_modalities),
            "prompt_version_metadata": prediction.prompt_version_metadata,
            "prompt_version_file": prediction.prompt_version_file,
            "prompt_sha256": prediction.prompt_sha256,
            "evaluation_record_path": prediction.evaluation_record_path,
            "report_path": prediction.report_path,
        }
        rows.append(row)
        if status == "incorrect":
            errors.append(row.copy())

    metrics = calculate_binary_metrics(truth_values, prediction_values)
    total_sessions = len(truth)
    metrics.update(
        {
            "model": model,
            "total_labeled_sessions": total_sessions,
            "records_found": len(records),
            "missing_records": len(missing),
            "abstentions": abstentions,
            "coverage": _rounded(
                _safe_divide(metrics["evaluated_sessions"], total_sessions)
            ),
        }
    )
    return metrics, rows, errors


def _cohen_kappa(first: Sequence[int], second: Sequence[int]) -> Optional[float]:
    if len(first) != len(second) or not first:
        return None
    total = len(first)
    observed = sum(a == b for a, b in zip(first, second)) / total
    first_positive = sum(first)
    second_positive = sum(second)
    expected = (
        first_positive * second_positive
        + (total - first_positive) * (total - second_positive)
    ) / (total * total)
    if expected == 1:
        return 1.0 if observed == 1 else None
    return (observed - expected) / (1 - expected)


def _exact_mcnemar_pvalue(first_only_correct: int, second_only_correct: int) -> float:
    discordant = first_only_correct + second_only_correct
    if discordant == 0:
        return 1.0
    lower_tail = sum(
        math.comb(discordant, value)
        for value in range(min(first_only_correct, second_only_correct) + 1)
    ) / (2**discordant)
    return min(1.0, 2 * lower_tail)


def evaluate_pairwise_agreement(
    model_records: Mapping[str, Mapping[str, PredictionRecord]],
    truth: Mapping[str, GroundTruth],
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    summaries: List[Dict[str, Any]] = []
    disagreements: List[Dict[str, Any]] = []
    models = sorted(model_records, key=_model_sort_key)
    for first_model, second_model in itertools.combinations(models, 2):
        first_values: List[int] = []
        second_values: List[int] = []
        both_correct = both_wrong = first_only_correct = second_only_correct = 0
        prediction_cross_tab = [[0, 0], [0, 0]]
        for exam_id in sorted(truth, key=_exam_sort_key):
            first = model_records[first_model].get(exam_id)
            second = model_records[second_model].get(exam_id)
            if (
                first is None
                or second is None
                or first.predicted_binary is None
                or second.predicted_binary is None
            ):
                continue
            first_values.append(first.predicted_binary)
            second_values.append(second.predicted_binary)
            prediction_cross_tab[first.predicted_binary][second.predicted_binary] += 1
            first_correct = first.predicted_binary == truth[exam_id].binary_label
            second_correct = second.predicted_binary == truth[exam_id].binary_label
            if first_correct and second_correct:
                both_correct += 1
            elif not first_correct and not second_correct:
                both_wrong += 1
            elif first_correct:
                first_only_correct += 1
            else:
                second_only_correct += 1
            if first.predicted_binary != second.predicted_binary:
                disagreements.append(
                    {
                        "model_a": first_model,
                        "model_b": second_model,
                        "exam_id": exam_id,
                        "true_label": truth[exam_id].display_label,
                        "model_a_prediction": first.assessment_label,
                        "model_b_prediction": second.assessment_label,
                        "model_a_correct": first_correct,
                        "model_b_correct": second_correct,
                        "model_a_evidence_strength": first.evidence_strength,
                        "model_b_evidence_strength": second.evidence_strength,
                        "model_a_key_timestamps": "; ".join(first.key_timestamps),
                        "model_b_key_timestamps": "; ".join(second.key_timestamps),
                    }
                )
        comparable = len(first_values)
        agreements = sum(a == b for a, b in zip(first_values, second_values))
        summaries.append(
            {
                "model_a": first_model,
                "model_b": second_model,
                "comparable_sessions": comparable,
                "prediction_agreements": agreements,
                "prediction_disagreements": comparable - agreements,
                "prediction_agreement_rate": _rounded(
                    _safe_divide(agreements, comparable)
                ),
                "cohen_kappa": _rounded(_cohen_kappa(first_values, second_values)),
                "both_correct": both_correct,
                "both_incorrect": both_wrong,
                "model_a_only_correct": first_only_correct,
                "model_b_only_correct": second_only_correct,
                "mcnemar_exact_pvalue": _rounded(
                    _exact_mcnemar_pvalue(first_only_correct, second_only_correct)
                ),
                "prediction_cross_tab_a_rows_b_columns": prediction_cross_tab,
            }
        )
    return summaries, disagreements


def load_baseline_evaluation(path: Path) -> Tuple[Optional[Dict[str, Any]], Dict[str, int]]:
    if not path.is_file():
        return None, {}
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    metrics = data.get("group_metrics")
    if not isinstance(metrics, Mapping):
        raise ValueError(f"Baseline evaluation has no group_metrics object: {path}")
    confusion = metrics.get("confusion_matrix", [[0, 0], [0, 0]])
    tn, fp = int(confusion[0][0]), int(confusion[0][1])
    fn, tp = int(confusion[1][0]), int(confusion[1][1])
    comparison = {
        "model": "Conventional baseline",
        "evaluation_method": str(data.get("validation", "leave_one_group_out")),
        "evaluated_sessions": tn + fp + fn + tp,
        "true_negative": tn,
        "false_positive": fp,
        "false_negative": fn,
        "true_positive": tp,
        "accuracy": metrics.get("accuracy"),
        "balanced_accuracy": metrics.get("balanced_accuracy"),
        "precision": metrics.get("precision"),
        "recall_sensitivity": metrics.get("recall"),
        "specificity": _rounded(_safe_divide(tn, tn + fp)),
        "f1": metrics.get("f1"),
        "false_positive_rate": metrics.get("false_positive_rate"),
        "roc_auc": metrics.get("roc_auc"),
        "confusion_matrix": confusion,
    }
    predictions: Dict[str, int] = {}
    for row in data.get("group_predictions", []):
        if isinstance(row, Mapping):
            exam_id = str(row.get("group_id", "")).strip()
            prediction = row.get("predicted_label")
            if exam_id and prediction in {0, 1}:
                predictions[exam_id] = int(prediction)
    return comparison, predictions


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames: List[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _comparison_metric_row(metrics: Mapping[str, Any]) -> Dict[str, Any]:
    return {
        "model": metrics["model"],
        "evaluation_method": "fixed archived LLM decisions",
        "evaluated_sessions": metrics["evaluated_sessions"],
        "true_negative": metrics["true_negative"],
        "false_positive": metrics["false_positive"],
        "false_negative": metrics["false_negative"],
        "true_positive": metrics["true_positive"],
        "accuracy": metrics["accuracy"],
        "balanced_accuracy": metrics["balanced_accuracy"],
        "precision": metrics["precision"],
        "recall_sensitivity": metrics["recall_sensitivity"],
        "specificity": metrics["specificity"],
        "f1": metrics["f1"],
        "false_positive_rate": metrics["false_positive_rate"],
        "roc_auc": "",
    }


def _build_session_comparison_rows(
    truth: Mapping[str, GroundTruth],
    model_records: Mapping[str, Mapping[str, PredictionRecord]],
    baseline_predictions: Mapping[str, int],
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    models = sorted(model_records, key=_model_sort_key)
    for exam_id in sorted(truth, key=_exam_sort_key):
        target = truth[exam_id]
        row: Dict[str, Any] = {
            "exam_id": exam_id,
            "true_label": target.display_label,
            "participant_role_evaluation_only": target.participant_role,
        }
        for model in models:
            prediction = model_records[model].get(exam_id)
            row[f"{model}_prediction"] = (
                prediction.assessment_label if prediction else "Missing record"
            )
            row[f"{model}_correct"] = (
                prediction is not None
                and prediction.predicted_binary is not None
                and prediction.predicted_binary == target.binary_label
            )
        if baseline_predictions:
            baseline_prediction = baseline_predictions.get(exam_id)
            row["Conventional baseline_prediction"] = (
                _display_label(baseline_prediction)
                if baseline_prediction in {0, 1}
                else "Missing record"
            )
            row["Conventional baseline_correct"] = (
                baseline_prediction == target.binary_label
                if baseline_prediction in {0, 1}
                else ""
            )
        rows.append(row)
    return rows


def _load_matplotlib() -> Tuple[Any, Any, Any]:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib.colors import BoundaryNorm, ListedColormap
        from matplotlib.patches import Patch
    except ImportError as exc:
        raise RuntimeError(
            "Figure generation requires matplotlib. Install it with: "
            "py -m pip install matplotlib"
        ) from exc
    return plt, (BoundaryNorm, ListedColormap), Patch


def plot_confusion_matrices(
    model_metrics: Sequence[Mapping[str, Any]],
    output_path: Path,
) -> None:
    plt, _, _ = _load_matplotlib()
    panel_count = len(model_metrics)
    figure, axes = plt.subplots(1, panel_count, figsize=(5.3 * panel_count, 4.8))
    if panel_count == 1:
        axes = [axes]
    maximum = max(
        max(max(row) for row in metrics["confusion_matrix"])
        for metrics in model_metrics
    )
    for axis, metrics in zip(axes, model_metrics):
        confusion = metrics["confusion_matrix"]
        axis.imshow(confusion, cmap="Blues", vmin=0, vmax=max(1, maximum))
        for row_index in range(2):
            for column_index in range(2):
                value = confusion[row_index][column_index]
                axis.text(
                    column_index,
                    row_index,
                    str(value),
                    ha="center",
                    va="center",
                    fontsize=15,
                    color="white" if value > maximum / 2 else "black",
                )
        axis.set_xticks([0, 1], ["Non-suspicious", "Suspicious"])
        axis.set_yticks([0, 1], ["Non-suspicious", "Suspicious"])
        axis.set_xlabel("Predicted behavioral class")
        axis.set_ylabel("Ground-truth behavioral class")
        axis.set_title(str(metrics["model"]))
    figure.suptitle("LLM session-level confusion matrices", fontsize=14)
    figure.subplots_adjust(left=0.08, right=0.97, bottom=0.16, top=0.82, wspace=0.34)
    figure.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(figure)


def plot_metric_comparison(
    comparison_rows: Sequence[Mapping[str, Any]],
    output_path: Path,
) -> None:
    plt, _, _ = _load_matplotlib()
    metrics = [
        ("accuracy", "Accuracy"),
        ("balanced_accuracy", "Balanced accuracy"),
        ("precision", "Precision"),
        ("recall_sensitivity", "Recall"),
        ("specificity", "Specificity"),
        ("f1", "F1-score"),
    ]
    colors = ["#2A9D8F", "#E76F51", "#6C757D", "#457B9D"]
    group_width = 0.78
    bar_width = group_width / max(1, len(comparison_rows))
    figure, axis = plt.subplots(figsize=(11, 6.2))
    positions = list(range(len(metrics)))
    for model_index, row in enumerate(comparison_rows):
        offsets = [
            position - group_width / 2 + bar_width / 2 + model_index * bar_width
            for position in positions
        ]
        values = [
            float(row[key]) if row.get(key) not in {None, ""} else float("nan")
            for key, _ in metrics
        ]
        bars = axis.bar(
            offsets,
            values,
            width=bar_width * 0.92,
            label=str(row["model"]),
            color=colors[model_index % len(colors)],
        )
        for bar, value in zip(bars, values):
            if math.isfinite(value):
                axis.text(
                    bar.get_x() + bar.get_width() / 2,
                    value + 0.018,
                    f"{value:.2f}",
                    ha="center",
                    va="bottom",
                    fontsize=8,
                    rotation=90,
                )
    axis.set_xticks(positions, [label for _, label in metrics])
    axis.set_ylim(0, 1.13)
    axis.set_ylabel("Metric value")
    axis.set_title("Session-level model performance comparison")
    axis.grid(axis="y", alpha=0.25)
    axis.legend(loc="upper center", bbox_to_anchor=(0.5, -0.13), ncol=3)
    figure.tight_layout()
    figure.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(figure)


def plot_session_prediction_map(
    truth: Mapping[str, GroundTruth],
    model_records: Mapping[str, Mapping[str, PredictionRecord]],
    baseline_predictions: Mapping[str, int],
    output_path: Path,
) -> None:
    plt, color_types, Patch = _load_matplotlib()
    BoundaryNorm, ListedColormap = color_types
    exams = sorted(truth, key=_exam_sort_key)
    row_names = ["Ground truth"] + sorted(model_records, key=_model_sort_key)
    value_rows: List[List[int]] = [[truth[exam].binary_label for exam in exams]]
    for model in sorted(model_records, key=_model_sort_key):
        values: List[int] = []
        for exam in exams:
            record = model_records[model].get(exam)
            values.append(
                record.predicted_binary
                if record is not None and record.predicted_binary is not None
                else -1
            )
        value_rows.append(values)
    if baseline_predictions:
        row_names.append("Conventional baseline")
        value_rows.append([baseline_predictions.get(exam, -1) for exam in exams])

    cmap = ListedColormap(["#9E9E9E", "#4C78A8", "#E45756"])
    norm = BoundaryNorm([-1.5, -0.5, 0.5, 1.5], cmap.N)
    figure, axis = plt.subplots(figsize=(12, 1.2 + 0.72 * len(row_names)))
    axis.imshow(value_rows, cmap=cmap, norm=norm, aspect="auto")
    for row_index, values in enumerate(value_rows):
        for column_index, value in enumerate(values):
            label = "A" if value == -1 else ("S" if value == 1 else "N")
            axis.text(
                column_index,
                row_index,
                label,
                ha="center",
                va="center",
                color="white",
                fontweight="bold",
            )
    axis.set_xticks(range(len(exams)), [exam.replace("EXAM-", "") for exam in exams])
    axis.set_yticks(range(len(row_names)), row_names)
    axis.set_xlabel("Exam session")
    axis.set_title("Ground truth and session-level predictions")
    axis.set_xticks([value - 0.5 for value in range(1, len(exams))], minor=True)
    axis.set_yticks([value - 0.5 for value in range(1, len(row_names))], minor=True)
    axis.grid(which="minor", color="white", linewidth=1.5)
    axis.tick_params(which="minor", bottom=False, left=False)
    axis.legend(
        handles=[
            Patch(facecolor="#4C78A8", label="N: Non-suspicious behavior"),
            Patch(facecolor="#E45756", label="S: Suspicious behavior"),
            Patch(facecolor="#9E9E9E", label="A: Abstained or missing"),
        ],
        loc="upper center",
        bbox_to_anchor=(0.5, -0.22),
        ncol=3,
    )
    figure.tight_layout()
    figure.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(figure)


def _format_metric(value: Any) -> str:
    if value is None or value == "":
        return "NA"
    return f"{float(value):.3f}"


def build_text_summary(
    truth: Mapping[str, GroundTruth],
    model_metrics: Sequence[Mapping[str, Any]],
    pairwise: Sequence[Mapping[str, Any]],
    baseline: Optional[Mapping[str, Any]],
) -> str:
    positive_count = sum(record.binary_label == 1 for record in truth.values())
    negative_count = len(truth) - positive_count
    lines = [
        "ARGUS-Lite LLM Output Evaluation Summary",
        "",
        "Unit of analysis: one independent participant/video session",
        f"Sessions: {len(truth)} ({positive_count} suspicious-group, "
        f"{negative_count} non-suspicious-group)",
        "Positive class: Suspicious behavior",
        "Ground-truth source: exam_labels.csv collapsed to one label per video_id",
        "Prompt version expected and validated: v1.3",
        "",
        "LLM session-level metrics",
    ]
    for metrics in model_metrics:
        lines.extend(
            [
                f"- {metrics['model']}:",
                (
                    f"  confusion TN={metrics['true_negative']}, "
                    f"FP={metrics['false_positive']}, "
                    f"FN={metrics['false_negative']}, "
                    f"TP={metrics['true_positive']}"
                ),
                (
                    "  accuracy={accuracy}, balanced_accuracy={balanced}, "
                    "precision={precision}, recall={recall}, "
                    "specificity={specificity}, f1={f1}"
                ).format(
                    accuracy=_format_metric(metrics.get("accuracy")),
                    balanced=_format_metric(metrics.get("balanced_accuracy")),
                    precision=_format_metric(metrics.get("precision")),
                    recall=_format_metric(metrics.get("recall_sensitivity")),
                    specificity=_format_metric(metrics.get("specificity")),
                    f1=_format_metric(metrics.get("f1")),
                ),
                (
                    "  coverage={coverage}, abstentions={abstentions}, "
                    "accuracy_95%_Wilson_CI=[{low}, {high}]"
                ).format(
                    coverage=_format_metric(metrics.get("coverage")),
                    abstentions=metrics.get("abstentions"),
                    low=_format_metric(metrics.get("accuracy_ci95_wilson_low")),
                    high=_format_metric(metrics.get("accuracy_ci95_wilson_high")),
                ),
            ]
        )
    lines.extend(["", "Pairwise LLM agreement"])
    for summary in pairwise:
        lines.append(
            "- {a} vs {b}: agreement={agreement}, kappa={kappa}, "
            "McNemar exact p={p}".format(
                a=summary["model_a"],
                b=summary["model_b"],
                agreement=_format_metric(summary.get("prediction_agreement_rate")),
                kappa=_format_metric(summary.get("cohen_kappa")),
                p=_format_metric(summary.get("mcnemar_exact_pvalue")),
            )
        )
    if baseline:
        lines.extend(
            [
                "",
                "Conventional evaluation baseline",
                (
                    "- accuracy={accuracy}, balanced_accuracy={balanced}, "
                    "precision={precision}, recall={recall}, "
                    "specificity={specificity}, f1={f1}"
                ).format(
                    accuracy=_format_metric(baseline.get("accuracy")),
                    balanced=_format_metric(baseline.get("balanced_accuracy")),
                    precision=_format_metric(baseline.get("precision")),
                    recall=_format_metric(baseline.get("recall_sensitivity")),
                    specificity=_format_metric(baseline.get("specificity")),
                    f1=_format_metric(baseline.get("f1")),
                ),
                "- This is a leave-one-group-out Logistic Regression baseline, not an LLM.",
            ]
        )
    lines.extend(
        [
            "",
            "Interpretation limits",
            "- With only 11 independent sessions, all estimates are preliminary.",
            "- Evidence strength is ordinal model language, not calibrated confidence.",
            "- ROC-AUC is not computed for LLMs because no continuous calibrated score exists.",
            "- Timestamp localization accuracy is not measured without independent event annotations.",
            "- participant_role is used only to document the experimental ground truth and was not supplied to the LLMs.",
        ]
    )
    return "\n".join(lines) + "\n"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate archived ARGUS-Lite LLM session decisions against "
            "video-level ground truth and compare model agreement."
        )
    )
    parser.add_argument("--input-root", type=Path, default=Path("."))
    parser.add_argument("--labels", type=Path, default=Path("exam_labels.csv"))
    parser.add_argument(
        "--llm-output-root",
        type=Path,
        default=Path("output_generation"),
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=Path("llm_evaluation_results"),
    )
    parser.add_argument(
        "--baseline-evaluation",
        type=Path,
        default=Path("baseline_results/logistic_regression_leave_one_group_out.json"),
    )
    parser.add_argument(
        "--model",
        action="append",
        default=[],
        help="Model directory name to include; repeat for multiple models.",
    )
    parser.add_argument("--expected-groups", type=int, default=11)
    parser.add_argument("--expected-prompt-version", default="1.3")
    parser.add_argument("--allow-missing", action="store_true")
    parser.add_argument("--allow-prompt-version-mismatch", action="store_true")
    parser.add_argument("--no-figures", action="store_true")
    return parser.parse_args()


def _resolve_from_root(root: Path, value: Path) -> Path:
    return value.resolve() if value.is_absolute() else (root / value).resolve()


def main() -> None:
    args = parse_args()
    input_root = args.input_root.resolve()
    labels_path = _resolve_from_root(input_root, args.labels)
    llm_output_root = _resolve_from_root(input_root, args.llm_output_root)
    results_dir = _resolve_from_root(input_root, args.results_dir)
    baseline_path = _resolve_from_root(input_root, args.baseline_evaluation)

    truth, label_row_count = load_ground_truth(labels_path)
    if len(truth) != args.expected_groups:
        raise ValueError(
            f"Found {len(truth)} independent video groups; "
            f"expected {args.expected_groups}."
        )
    model_directories = discover_model_directories(llm_output_root, args.model)

    model_records: Dict[str, Dict[str, PredictionRecord]] = {}
    validation_warnings: List[str] = []
    for model, model_dir in model_directories:
        records, warnings = load_model_predictions(
            model,
            model_dir,
            truth,
            args.expected_prompt_version.removeprefix("v"),
            args.allow_prompt_version_mismatch,
        )
        model_records[model] = records
        validation_warnings.extend(warnings)

    prompt_hashes = {
        record.prompt_sha256
        for records in model_records.values()
        for record in records.values()
    }
    if len(prompt_hashes) != 1 and not args.allow_prompt_version_mismatch:
        raise ValueError(
            "Archived prompt.txt files are not byte-for-byte identical across all runs."
        )
    if len(prompt_hashes) != 1:
        validation_warnings.append(
            "Archived prompt files have multiple SHA-256 hashes."
        )

    all_session_rows: List[Dict[str, Any]] = []
    all_error_rows: List[Dict[str, Any]] = []
    model_metrics: List[Dict[str, Any]] = []
    for model in sorted(model_records, key=_model_sort_key):
        metrics, rows, errors = evaluate_model(
            model,
            model_records[model],
            truth,
            args.allow_missing,
        )
        model_metrics.append(metrics)
        all_session_rows.extend(rows)
        all_error_rows.extend(errors)

    pairwise, disagreements = evaluate_pairwise_agreement(model_records, truth)
    baseline_metrics, baseline_predictions = load_baseline_evaluation(baseline_path)

    comparison_rows = [_comparison_metric_row(metrics) for metrics in model_metrics]
    if baseline_metrics:
        comparison_rows.append(dict(baseline_metrics))
    session_comparison_rows = _build_session_comparison_rows(
        truth,
        model_records,
        baseline_predictions,
    )

    results_dir.mkdir(parents=True, exist_ok=True)
    figures_dir = results_dir / "figures"
    if not args.no_figures:
        figures_dir.mkdir(parents=True, exist_ok=True)

    predictions_path = results_dir / "llm_session_predictions.csv"
    metrics_path = results_dir / "llm_model_metrics.csv"
    comparison_path = results_dir / "model_metric_comparison.csv"
    pairwise_path = results_dir / "llm_pairwise_agreement.csv"
    disagreements_path = results_dir / "llm_disagreements.csv"
    errors_path = results_dir / "llm_error_analysis.csv"
    session_comparison_path = results_dir / "session_prediction_comparison.csv"
    summary_json_path = results_dir / "llm_evaluation_summary.json"
    summary_text_path = results_dir / "llm_evaluation_summary.txt"

    _write_csv(predictions_path, all_session_rows)
    _write_csv(metrics_path, model_metrics)
    _write_csv(comparison_path, comparison_rows)
    _write_csv(pairwise_path, pairwise)
    _write_csv(disagreements_path, disagreements)
    _write_csv(errors_path, all_error_rows)
    _write_csv(session_comparison_path, session_comparison_rows)

    positive_count = sum(record.binary_label == 1 for record in truth.values())
    negative_count = len(truth) - positive_count
    summary = {
        "evaluation_schema_version": 1,
        "purpose": "session-level evaluation of archived ARGUS-Lite LLM decisions",
        "unit_of_analysis": "one independent participant/video session",
        "positive_class": POSITIVE_LABEL,
        "negative_class": NEGATIVE_LABEL,
        "abstention_class": ABSTENTION_LABEL,
        "ground_truth_mapping": {
            "cheating": POSITIVE_LABEL,
            "non_cheating": NEGATIVE_LABEL,
        },
        "dataset": {
            "source": str(labels_path),
            "source_csv_rows": label_row_count,
            "independent_sessions": len(truth),
            "positive_sessions": positive_count,
            "negative_sessions": negative_count,
            "expected_sessions": args.expected_groups,
        },
        "prompt_validation": {
            "expected_version": args.expected_prompt_version.removeprefix("v"),
            "unique_prompt_sha256": sorted(prompt_hashes),
            "all_prompt_files_identical": len(prompt_hashes) == 1,
        },
        "methodology": {
            "classification_metrics": (
                "Computed once per independent video from the machine-readable "
                "assessment_label."
            ),
            "abstentions": (
                "Not evaluable/insufficient evidence is excluded from binary "
                "metrics and reported through coverage."
            ),
            "agreement": (
                "Pairwise prediction agreement, Cohen's kappa, and exact McNemar "
                "comparison of paired correctness."
            ),
            "accuracy_interval": "95% Wilson score interval",
            "timestamp_evaluation": (
                "Format and duration bounds are validated; behavioral localization "
                "accuracy is not estimated without independent event annotations."
            ),
            "participant_role": (
                "Retained only as evaluation metadata and never treated as a model input."
            ),
        },
        "software": {
            "python": platform.python_version(),
        },
        "models": {metrics["model"]: metrics for metrics in model_metrics},
        "pairwise_agreement": pairwise,
        "conventional_baseline": baseline_metrics,
        "validation_warnings": validation_warnings,
        "limitations": [
            "Only 11 independent sessions are available, so estimates are preliminary.",
            "Evidence strength is ordinal language, not calibrated probability.",
            "LLM ROC-AUC is not available because the records contain no continuous calibrated score.",
            "Session labels do not provide event-level timestamp ground truth.",
            "The conventional baseline was refined during development and requires confirmation on untouched participants.",
        ],
        "artifacts": {
            "llm_session_predictions": str(predictions_path),
            "llm_model_metrics": str(metrics_path),
            "model_metric_comparison": str(comparison_path),
            "llm_pairwise_agreement": str(pairwise_path),
            "llm_disagreements": str(disagreements_path),
            "llm_error_analysis": str(errors_path),
            "session_prediction_comparison": str(session_comparison_path),
        },
    }
    summary_json_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    summary_text_path.write_text(
        build_text_summary(truth, model_metrics, pairwise, baseline_metrics),
        encoding="utf-8",
    )

    if not args.no_figures:
        confusion_path = figures_dir / "llm_confusion_matrices.png"
        metric_figure_path = figures_dir / "model_metric_comparison.png"
        session_map_path = figures_dir / "session_prediction_map.png"
        plot_confusion_matrices(model_metrics, confusion_path)
        plot_metric_comparison(comparison_rows, metric_figure_path)
        plot_session_prediction_map(
            truth,
            model_records,
            baseline_predictions,
            session_map_path,
        )
        summary["artifacts"]["llm_confusion_matrices"] = str(confusion_path)
        summary["artifacts"]["model_metric_comparison_figure"] = str(
            metric_figure_path
        )
        summary["artifacts"]["session_prediction_map"] = str(session_map_path)
        summary_json_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(f"[done] Evaluated {len(truth)} independent session(s).")
    print(f"[done] Models: {', '.join(sorted(model_records, key=_model_sort_key))}")
    print(f"[done] Results: {results_dir}")
    for metrics in model_metrics:
        print(
            f"[metric] {metrics['model']}: accuracy={metrics['accuracy']}, "
            f"balanced_accuracy={metrics['balanced_accuracy']}, "
            f"f1={metrics['f1']}"
        )


if __name__ == "__main__":
    main()
